<div class="menu">
<div class="dropdown">
<a href="javascript:AddTXT('textarea', '[b] [/b]')"><img src="/img/bb/bold.gif" alt="bold"></a>
<a href="javascript:AddTXT('textarea', '[i] [/i]')"><img src="/img/bb/italics.gif" alt="italics"></a>
<a href="javascript:AddTXT('textarea', '[u] [/u]')"><img src="/img/bb/underline.gif" alt="underline"></a>
<a href="javascript:AddTXT('textarea', '[cit] [/cit]')"><img src="/img/bb/quote.gif" alt="quote"></a>
<a href="javascript:AddTXT('textarea', '[del] [/del]')"><img src="/img/bb/strike.gif" alt="strike"></a>
<a href="javascript:AddTXT('textarea', '[url=Адрес] [/url]')"><img src="/img/bb/link.gif" alt="link"></a>
<a href="javascript:AddTXT('textarea', '[color=Цвет] [/color]')"><img src="/img/bb/color.gif" alt="color"></a>
<a href="javascript:AddTXT('textarea', ' :37: ')"><img src="/img/smiles/37.gif" alt="sm"></a>
<a href="javascript:AddTXT('textarea', ' :36: ')"><img src="/img/smiles/36.gif" alt="sm"></a>
<a href="javascript:AddTXT('textarea', ' :9: ')"><img src="/img/smiles/9.gif" alt="sm"></a>
<a href="javascript:AddTXT('textarea', ' :20: ')"><img src="/img/smiles/20.gif" alt="sm"></a>
<a href="javascript:AddTXT('textarea', ' :27: ')"><img src="/img/smiles/27.gif" alt="sm"></a>
<a href="javascript:AddTXT('textarea', ' :15: ')"><img src="/img/smiles/15.gif" alt="sm"></a>
<a href="javascript:AddTXT('textarea', ' :16: ')"><img src="/img/smiles/16.gif" alt="sm"></a>
<a href="javascript:AddTXT('textarea', ' :17: ')"><img src="/img/smiles/17.gif" alt="sm"></a>
</div>
</div>
