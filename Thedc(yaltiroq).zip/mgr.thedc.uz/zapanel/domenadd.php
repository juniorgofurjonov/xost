<?php
$title='Новый домен';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
    $ontarif = $connect->prepare("select * from `tarifs_hosting` where `id` = ?");
    $ontarif->execute(array($user['id_tarif']));
    $ustarif = $ontarif->fetch(PDO::FETCH_LAZY);
    $server = $connect->query("SELECT * FROM `servers` WHERE `id` = '".abs(intval($ustarif[id_server]))."'");
    $server = $server->fetch(PDO::FETCH_LAZY);
echo '<div class="title">Новый домен</div>';	

    
    if (empty($_POST['submit'])) {
        echo '<div class="menu"><form action="/domen/add" method="post">' . "\n";
        echo 'Доменное имя:  ' . "\n";
        echo '<input name="name" type="text"/>  <br/><b>Пример</b>: example.uz | poddomen.example.uz<br />' . "\n";
		echo 'Перенаправте домен на <br />' . "\n";
        echo 'Наши DNS:<br />' . "\n";
        echo 'ns1.thedc.uz<br/>ns2.thedc.uz<br />' . "\n";
        echo '<input class="btn btn-default" name="submit" type="submit" value="Добавить" />' . "\n";
        echo '</form></div>' . "\n";
        echo '<div class="menu"><a href="/domen">&laquo; Назад</div></a> ';
       } else {
	$siteisp = 	'thedc.uz';   
    $dm_filter_1simb = strlen(htmlentities($_POST['name']));
	$dm_filter_2simb = strlen('thedc.uz');
	$dm_filter_3simb = $dm_filter_1simb - $dm_filter_2simb;
	if($dm_filter_3simb > '0'){
	$dm_filter_ok = 1;
	$dm_filter_filt = substr($_POST['name'],$dm_filter_3simb,$dm_filter_1simb);
	}else{
	$dm_filter_ok = 0;
	$dm_filter_filt = '';
	}
	if(($dm_filter_ok=='1') and ($dm_filter_filt == 'thedc.uz')){
	echo'<div class=menu><center><font color="red">Ошибка! домен системный и его не возможно добавить в качестве адреса сайта!</font></center></div>';
	echo '<div class="menu"><a href="/domen">Продолжить</a></div>';		
     } else {
		// Фильтрация
		$name = htmlentities($_POST['name']);	
		// Mail домен
		$content = api_query("https://".$server->ip."/ispmgr?func=emaildomain.edit&defaction=ignore&ipsrc=auto&owner=".$user['isp_login']."&name=".$name."&authinfo=".$user['isp_login'] . ":" . $user['isp_pass']."&out=xml&sok=yes");
        // Web домен
        $content = api_query("https://".$server->ip."/ispmgr?func=webdomain.edit&owner=".$user['isp_login']."&authinfo=".$user['isp_login'] . ":" . $user['isp_pass']."&name=".$name."&email=admin@".$name."&sok=yes&out=xml");
        $parse_xml = simplexml_load_string($content);
        if (isset($parse_xml->ok)) {
            echo '<div class="menu">' . "\n";
            echo '<center><font color="gren">Доменное имя успешно добавлено!</font></center>' . "\n";
			echo '</div>' . "\n";
            echo '<div class="menu"><a href="/domen">Продолжить</a></div>' . "\n";
        } else {
            echo '<div class="menu">' . "\n";
            echo '<center><font color="red">Ошибка при добавлении доменного имени!</font></center>' . "\n";
			echo '</div>' . "\n";
            echo '<div class="menu"><a href="/domen">Продолжить</a></div>' . "\n";
        }
    }
	   }

} else {
header('Location: /');
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>