<?php
$title = 'Смена E-mail';
require_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active)) {
$email_s = $connect->prepare("select count(*) from `users` where `email` = ?");
    echo '<div class="title">Смена E-mail</div>';

    if (isset($_SESSION['email']) && isset($_SESSION['email_key'])) {

        // Юзер может быть хитёр :)
        $email_s->execute(array($_SESSION['email']));

        if ($_SESSION['email'] == $user['email'] || $email_s->fetchColumn()) {

            unset($_SESSION['email'], $_SESSION['email_key']);

            header('Location: /user/email');

        } else {

            if (isset($_POST['cancel'])) {

                unset($_SESSION['email'], $_SESSION['email_key']);

                header('Location: /user/email');

            }
            elseif (isset($_POST['email_verify'])) {

                $error = '';

                if (empty($_POST['email_key'])) {
                    $error.= 'Введите код подтверждения!<br/>';
                }
                elseif ($_POST['email_key'] != $_SESSION['email_key']) {
                    $error.= 'Код подтверждения неверный!<br/>';
                }
                if ($error) {
                    echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
                } else {

                    $stmt = $connect->prepare("update `users` set `email` = ? where `id` = ?");

                    if ($stmt->execute(array($_SESSION['email'], $user['id']))) {

                        unset($_SESSION['email'], $_SESSION['email_key']);

                        header('Location: /user/email');

                    } else {
                        echo '<div class="menu"><center><font color="red">Произошла ошибка!</font></center></div>';
                    }

                }

            }

            echo '<div class="menu">
            <form action="" method="POST">
            E-mail: '.$_SESSION['email'].'<br/>#####################<br/>
            Код подтверждения:<br/><input type="text" name="email_key"><br/>
            <input class="btn btn-default" type="submit" name="email_verify" value="Подтвердить E-mail"><input class="btn btn-default" type="submit" name="cancel" value="Отмена">
            <div class="menu"><center><font color="gren">На <font color="red">'.$user['email'].'</font> было отправлено письмо с кодом подтверждения.</font></center></div>
            </form></div>';

        }

    } else {

        if (isset($_POST['submit'])) {

            $error = '';

            // Поиск e-mail в базе
            $email_s->execute(array($_POST['email']));

            if (empty($_POST['email'])) {
                $error.= 'Поле e-mail обязательно для заполнения!<br/>';
            }
            elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                $error.= 'Поле e-mail заполнено неверно!<br/>';
            }
            elseif ($_POST['email'] == $user['email']) {
                $error.= 'У вас и так этот e-mail!<br/>';
            }
            elseif ($email_s->fetchColumn()) {
                $error.= 'Пользователь с таким e-mail уже зарегистрирован!<br/>';
            }
            if ($error) {
                echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
            } else {

                $_SESSION['email'] = $_POST['email'];

                $_SESSION['email_key'] = random_int(11111, 99999);

                mailto(
                    $user['email'],
                    'Смена E-mail TheDC.uz',
                    'Код подтверждения: '.$_SESSION['email_key'],
                    $set['mail']
                );

                header('Location: /user/email');

            }

        }

        echo '<div class="menu">
        <form action="" method="POST">
        Нынешний E-mail: '.$user['email'].'<br/>############################<br/>
        Новый E-mail:<br/><input type="email" name="email"><br/>
        <input class="btn btn-default" type="submit" name="submit" value="Продолжить">
        </form></div>';

    }


} else {
    header('Location: /');
}

require($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>