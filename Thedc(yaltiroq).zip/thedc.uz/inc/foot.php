<?php
list($msec,$sec)=explode(chr(32),microtime());

if ($_SERVER['PHP_SELF'] != '/index.php') {
echo '</div>';
echo '<div class="menu"><a href="/"><img src="/inc/style/img/up.png"> Bosh sahifa</a></div> '; 
}

echo '</div><footer>';

?>

<span>&copy; <b> TheDC.uz </b> - <?=date('Y');?></span>
<div class="center">tezlik <?=round(($sec+$msec)-$headtime,3)?> sekund</div>
<script>
window.replainSettings = { id: '001fc292-aa2f-4374-a2e1-88f0315bb4a4' };
(function(u){var s=document.createElement('script');s.type='text/javascript';s.async=true;s.src=u;
var x=document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s,x);
})('https://widget.replain.cc/dist/client.js');
</script>


      </footer>
    </div>
<center>

<script>
    var btn = $('#button');

$(window).scroll(function() {
  if ($(window).scrollTop() > 300) {
    btn.addClass('show');
  } else {
    btn.removeClass('show');
  }
});

btn.on('click', function(e) {
  e.preventDefault();
  $('html, body').animate({scrollTop:0}, '300');
});
</script>

<?

/*
<div class="center">Ген. <?=round(($sec+$msec)-$headtime,3)?> сек.</div>
*/
?>
   </body>
</html>