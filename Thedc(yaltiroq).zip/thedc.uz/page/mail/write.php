<?php
$title = 'Новое сообщение';
require_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active)) {

    $in_mail = $connect->prepare("insert into `mail` set `time` = ?, `from` = ?, `to` = ?, `text` = ?");

    echo '<div class="title">Новое сообщение</div>';

    SmilesAndBB();

    if (isset($_POST['submit'])) {

        $row = user($_POST['who'], 1);

        $error = '';

        if ($user['datereg'] > time() - 60 * $sys['system']['fludtime'] && $adm_id == 0) {
            $error.= 'Для возможности отправлять сообщения с момента регистрации должно пройти: '.restime(60 * $sys['system']['fludtime']).'!<br/>';
        } else {
            if (empty($_POST['who'])) {
                $error.= 'Введите логин получателя!<br/>';
            }
            elseif (!$row) {
                $error.= 'Пользователь с таким логином не зарегистрирован!<br/>';
            }
            elseif ($_POST['who'] == $user['login']) {
                $error.= 'Нельзя отправлять сообщения самому себе!<br/>';
            }
            elseif (!privateMail($row, $user['id'])) {
                $error.= 'Данному пользователю могут отправлять сообщения только друзья!<br/>';
            }
            elseif (in_blacklist($user['id'], $row['id']) || in_blacklist($row['id'], $user['id'])) {
                $error.= 'Вы не можете писать этому пользователю!<br/>';
            }
            if (empty($_POST['text'])) {
                $error.= 'Введите сообщение!<br/>';
            }
            elseif (mb_strlen($_POST['text']) < 2 || mb_strlen($_POST['text']) > 25000) {
                $error.= 'Текст должен содержать не менее 2 символов и не более 25000 символов!<br/>';
            }
            if (file_exists($_FILES['filename']['tmp_name'])) {
                if (!BeforeUpload::AttachFile($_FILES['filename'])) {
                    $error.= 'Неверный тип файла!<br/>';
                }
                if ($_FILES['filename']['size'] > $sys['system']['upload_mail']) {
                    $error.= 'Максимальный размер файла - '.byte_conv($sys['system']['upload_mail']).'!<br/>';
                }
            }
        }
        if ($error) {
            echo '<div class="menu">'.$error.'</div>';
        } else {
            if ($in_mail->execute(array(time(), $user['id'], $row['id'], $_POST['text']))) {
                // Загрузка файла
                if (file_exists($_FILES['filename']['tmp_name'])) {
                    $lid = $connect->LastInsertId();
                    $files = $lid."_mail_".random_int(11111, 99999)."_".$_FILES['filename']['name'];
                    move_uploaded_file($_FILES['filename']['tmp_name'], $_SERVER["DOCUMENT_ROOT"]."/files/".$files);
                }
                // Добавляем в контакты
                contact_add($user['id'], $row['id']);
                // Очки дружбы
                friendPoint($user['id'], $row['id']);
                header('Location: /mail/read/'.$row['id']);
            } else {
                echo '<div class="menu">Произошла ошибка!</div>';
            }
        }
    }

    echo '<div class="menu">
    <form action="" method="POST" enctype="multipart/form-data">
    Логин получателя:<br/><input type="text" name="who"><br/>
    Сообщение:<br/><textarea data-select-range id="message" name="text" rows="5" cols="25"></textarea><br/>
    Прикрепить файл:<br/><input type="file" name="filename"><br/>
    <input type="submit" name="submit" value="Отправить"/>
    </form></div>';

} else {
    header('Location: /');
}

require($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>