<?php
$title = 'Профиль';
require_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if ($adm_id == 5) {

    $row = user($id);

    if ($row) {
        echo '<div class="title">Профиль: '.filter($row['login']).' '.online($id).'  </div>';
        echo '<div class="menu">'.($row['ban'] > time() ? '<font color=red><center><b>Этот пользователь заблокирован до '.date('d.m.Y H:i', $row['ban']).'!</b></center></font>' : '').'
        
        <b>Последний визит</b>: '.vremja($row['lasttime']).'<br/>
        <b>Дата регистрации</b>: '.vremja($row['datereg']).'<br/>
        <b>ID</b>: '.$row['id'].'
        </div>';
        echo '<div class="title">INFO</div>';
        echo '<div class="menu">';
$ontarif = $connect->prepare("select * from `tarifs_hosting` where `id` = ?");
$ontarif->execute(array($row['id_tarif']));
$ustarif = $ontarif->fetch(PDO::FETCH_LAZY);
$usm=$row[money];
$tcm=$ustarif['price_day'];
if ($tcm == 0) {$k='0';}else{
for ($k=0;$tcm <=$usm;$k++){
    $usm=$usm-$tcm;
}
}
if ($k >= 1) {
    $allc = 86400 * $k;
}else{$allc='0';}
if ($row['activ'] >= 2) {
echo '<b>Осталось дней</b>: '.order_day(($row['time_work'] + $allc)).' (Активен до: '.vremja(($row['time_work'] + $allc)).' )<br/>
'.(order_day($row['time_work'],true) < 0.01 ? '<font color="red"><b>До сброс аккаунт осталось</b>: '.order_day(($row['time_work'] + (84600 * 7))).' дней. </font><br/>' : '').' ';}
echo 'Тариф: <b>'.$ustarif['name'].' ('.$ustarif['price_day'].' руб/день)</b><br/>';
echo '</div>';
if (empty($id==1)) {
            echo '<div class="title">Управление</div>';

            if (isset($_GET['edit'])) {
                if (isset($_POST['cancel'])) {
                    header('Location: /adm/users/id/'.$id);
                }
                elseif (isset($_POST['red'])) {
                    $error = '';
                    if (!is_numeric($_POST['rating'])) {
                        $error.= 'Активность заполнен неверно!<br/>';
                    } 
                    if (empty($_POST['email'])) {
                        $error.= 'Поле e-mail обязательно для заполнения!<br/>';
                    }
                    elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                        $error.= 'Поле e-mail заполнено неверно!<br/>';
                    }elseif ($_POST['accesstos'] < 1 && $_POST['accesstos'] > 2) {
                        $error.= ' '.$_POST['accesstos'].' Поле Доступ к Смена тариф заполнено неверно!<br/>';
                    }elseif ($_POST['accesstosm'] < 1 && $_POST['accesstosm'] > 2) {
                        $error.= 'Поле Доступ к Передать деньги заполнено неверно!<br/>';
                    }
                    if (empty($_POST['wmr'])) {
                        $error.= 'Введите код активатция!<br/>';
                    }
                    if (!empty($error)) {
                        echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
                    } else {
                        $stmt = $connect->prepare("update `users` set `test` = ?, `wmr` = ?, `email` = ?, `accesstos` = ?, `accesstosm` = ? where `id` = ?");
                        if ($stmt->execute(array($_POST['rating'], $_POST['wmr'], $_POST['email'], $_POST['accesstos'], $_POST['accesstosm'], $id))) {
                            header('Location: /adm/users/id/'.$id);
                        } else {
                            echo '<div class="menu"><center><font color="red">Произошла ошибка!</font></center></div>';
                        }
                    }
                }
                echo '<div class="menu">
                <form action="" method="POST">
                <b>Активность</b>:<br/><input type="text" name="rating" value="'.$row['test'].'"><br/>
                <b>E-mail</b>:<br/><input type="email" name="email" value="'.$row['email'].'"><br/>
                <b>Код Активатция</b>:<br/><input type="text" name="wmr" value="'.$row['wmr'].'"><br/> 
                <b>Доступ к Смена Тариф</b>:<br/><select name="accesstos">';
                if ($row['accesstos'] == 2){
                    echo '<option value="2">Вкл</option>'; 
                    echo '<option value="1">Откл</option>';
                }else{
                    echo '<option value="1">Откл</option>';
                    echo '<option value="2">Вкл</option>';
                }
                echo '</select><br/> 
                <b>Доступ к Передать деньги</b>:<br/><select name="accesstosm">';
                if ($row['accesstosm'] == 2){
                    echo '<option value="2">Вкл</option>'; 
                    echo '<option value="1">Откл</option>';
                }else{
                    echo '<option value="1">Откл</option>';
                    echo '<option value="2">Вкл</option>';
                }
                echo '</select><br/> 
                <input class="btn btn-default" type="submit" name="red" value="Сохранить">
                <input class="btn btn-default" type="submit" name="cancel" value="Отмена">
                </form></div>';
            }
            $accv = true;
            if (isset($_GET['adm']) && $id != $user['id'] && $accv) {
                if (isset($_POST['cancel'])) {
                    header('Location: /adm/users/id/'.$id);
                }
                elseif (isset($_POST['ok'])) {
                    $stmt = $connect->prepare("update `users` set `admin` = ? where `id` = ?");
                    if ($stmt->execute(array($_POST['status'], $id))) {
                        header('Location: /adm/users/id/'.$id);
                    } else {
                        echo '<div class="menu"><center><font color="red">Произошла ошибка!</font></center></div>';
                    }
                }
                echo '<div class="menu">
                <form action="" method="POST">
                <b>Статус</b>:<br/><select name="status">';
                foreach ($admList as $key => $value)
                    echo '<option value="'.$key.'">'.$value.'</option>'; 
                echo '</select><br/> 
                <input class="btn btn-default" type="submit" name="ok" value="Назначить">
                <input class="btn btn-default" type="submit" name="cancel" value="Отмена">
                </form></div>';
            } 
            elseif (isset($_GET['ban']) && $id != $user['id']) {
                $ban = $connect->prepare("update `users` set `ban` = ? where `id` = ?"); 
                if ($row['ban'] > time()) {
                    if (isset($_POST['cancel'])) {
                        header('Location: /adm/users/id/'.$id);
                    }
                    elseif (isset($_POST['ok'])) {
                        if ($ban->execute(array(0, $id))) {
                            header('Location: /adm/users/id/'.$id);
                        } else {
                            echo '<div class="menu"><center><font color="red">Произошла ошибка!</font></center></div>';
                        }
                    } 
                    echo '<div class="menu">
                    <form action="" method="POST">
                    <input class="btn btn-default" type="submit" name="ok" value="Разблокировать аккаунт">
                    <input class="btn btn-default" type="submit" name="cancel" value="Отмена">
                    </form></div>';
                } else {
                    if (isset($_POST['cancel'])) {
                        header('Location: /adm/users/id/'.$id);
                    }
                    elseif (isset($_POST['ok'])) {
                        $error = '';
                        if (empty($_POST['col'])) {
                            $error.= 'Введите количество часов!<br/>';
                        } 
                        if (!empty($error)) {
                            echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
                        } else {
                            $col = intval(abs($_POST['col']));
                            $time = $col * 3600 + time(); 
                            if ($ban->execute(array($time, $id))) {
                                header('Location: /adm/users/id/'.$id);
                            } else {
                                echo '<div class="menu"><center><font color="red">Произошла ошибка!</font></center></div>';
                            }
                        }
                    }
                    echo '<div class="menu">
                    <form action="" method="POST">
                    <b>Количество часов</b>:<br/><input type="text" name="col" maxlength="10"/><br/>
                    <input class="btn btn-default" type="submit" name="ok" value="Заблокировать аккаунт">
                    <input class="btn btn-default" type="submit" name="cancel" value="Отмена">
                    </form></div>';
                }
            }
            elseif (isset($_GET['del']) && $id != $user['id']) {
                if (isset($_POST['cancel'])) {
                    header('Location: /adm/users/id/'.$id);
                } 
                elseif (isset($_POST['yes'])) {

                    // Удаляем юзера
                    $del = $connect->prepare("delete from `users` where `id` = ?");
                    // Удаляем сообщения
                    $del_mail = $connect->prepare("delete from `note` where `id_user` = :user");
                    // Чистим логи авторизаций
                    $del_authlog = $connect->prepare("delete from `logs_user` where `id_user` = ?");
                    // Чистим плюсы/минусы
                    $del_respect = $connect->prepare("delete from `logs_money` where `id_user` = ?");
                    // Tiket
                    $del_tiket = $connect->prepare("delete from `tickets` where `id_user` = ?");
                    $del_tiket_msg = $connect->prepare("delete from `tickets_msg` where `id_user` = ?");

                    if ($del->execute(array($id)) && $del_mail->execute(array(':user' => $id)) && $del_authlog->execute(array($id)) && $del_respect->execute(array($id)) && $del_tiket->execute(array($id)) && $del_tiket_msg->execute(array($id))) {
                        header('Location: /adm/users');
                    } else {
                        echo '<div class="menu"><center><font color="red">Произошла ошибка!</font></center></div>';
                    }
                }

                echo '<div class="menu">
                <form action="" method="POST">
                <input class="btn btn-default" type="submit" name="yes" value="Удалить аккаунт"/> 
                <input class="btn btn-default" type="submit" name="cancel" value="Отмена"/>
                </form></div>';
            }
            elseif (isset($_GET['cleartg'])) {
                if (isset($_POST['cancel'])) {
                    header('Location: /adm/users/id/'.$id);
                } 
                elseif (isset($_POST['yes'])) {

                    $infom = user($id);
                    if ($infom[tg_id]) {
                        $sesss=md5($time);
                        $sql122 = $connect->prepare("UPDATE `users` SET `tg_id` = ?, `tg_sess` = ? WHERE `id` = ?");
                        $sql122->execute(array('0', $sesss, $id));
                        header('Location: /adm/users/id/'.$id);
                       }else {
                         echo '<div class="menu"><center><font color="red">Произошла ошибка!</font></center></div>';  
                       }
                    
                }

                echo '<div class="menu">
                <form action="" method="POST">
                <input class="btn btn-default" type="submit" name="yes" value="Сброс TG Аккаунт"/> 
                <input class="btn btn-default" type="submit" name="cancel" value="Отмена"/>
                </form></div>';
            }
            elseif (isset($_GET['clearsess'])) {
                if (isset($_POST['cancel'])) {
                    header('Location: /adm/users/id/'.$id);
                } 
                elseif (isset($_POST['yes'])) {
                    $reset = $connect->prepare("update `authlog` set `status` = '0' where `uid` = ?");
                    if ($reset->execute(array($id))) {
                    header('Location: /adm/users/id/'.$id);
                    } else {
                    echo '<div class="err">Произошла ошибка!</div>';
                    }
                }

                echo '<div class="menu">
                <form action="" method="POST">
                <input class="btn btn-default" type="submit" name="yes" value="Сброс сессия логин"/> 
                <input class="btn btn-default" type="submit" name="cancel" value="Отмена"/>
                </form></div>';
            }
            elseif (isset($_GET['authcp'])) {
                if (isset($_POST['cancel'])) {
                    header('Location: /adm/users/id/'.$id);
                } 
                elseif (isset($_POST['yes'])) {
                        header('Location: /authcp/accessadm/'.$id);
                }

                echo '<div class="menu">
                <form action="" method="POST">
                <input class="btn btn-default" type="submit" name="yes" value="Вход на панель"/> 
                <input class="btn btn-default" type="submit" name="cancel" value="Отмена"/>
                </form></div>';
            }

if ($row[activ]==0) {$c1='<font color="red">аккаунт не активирован!</font> (0)';}
if ($row[activ]==1) {$c1='<font color="red">аккаунт не активирован!</font>(1)';}
if ($row[activ]==2) {$c1='<font color="gren">аккаунт Активен!</font>(2)';}
if ($row[activ]==3) {$c1='<font color="red">аккаунт отключен!</font>(3)';}
if ($row[activ]==4) {$c1='<font color="red">аккаунт блокирован!</font>(4)';}
if (empty($c1)) {$c1='Error';}
            echo '<div class="menu">
            <b>Баланс</b>: '.$row['money'].' Руб<br/>
            <b>Активность</b>: ['.$c1.']<br/>
            <b>Код активатция</b>: '.$row['wmr'].'<br/>
            <b>Активность почта</b>: '.($row['test'] == 2 ? '<font color=gren>Активен!</font>' : '<font color=red>Не активен!</font>').'<br/>
            <b>E-mail</b>: '.filter2($row['email']).'<br/>
            <b>Авторизаций</b>: <br/>
            <b>Telegram</b>: '.(empty($row['tg_id']) ? 'None' : $row['tg_id']).'<br/>
            <div class="butt2">
            '.($id != $user['id'] ? '<a href="?del"> [Удл] </a>
            <a href="?adm"> [Должность] </a> <a href="?ban">'.($row['ban'] > time() ? ' [Разблок..] ' : ' [Заблок..] ').'</a>
            ' : '').'
            <a href="?edit"> [Ред..]</a>
            '.($row['tg_id'] ? '<a href="?cleartg"> [Сброс TG]</a>' : '').'
            <a href="?clearsess"> [Сброс сессия]</a>
            </div>
            </div>'; // <a href="?adm"> [Должность] </a>
            
}else{echo '<div class="menu">OOPS</div>';}
echo '<div class="menu">&bull;<a href="/adm/users"> Назад</a></div>';
    } else {
        header('Location: /adm/users');
    }
} else {
    header('Location: /?404');
}

require($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>