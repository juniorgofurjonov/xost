<?php
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/function.php");
include_once($_SERVER["DOCUMENT_ROOT"]."/modnn/WapkassaClass.php");

try {
    // Инициализация класса с id сайта и секретным ключом
    $wapkassa = new WapkassaClass($wpkid, $wpkh);

    // Проверка обработчика (PING)
    if ($wapkassa->ping($_POST)) {
        // возврат успешной проверки
        echo $wapkassa->successPing();
    } else {
        // Парсинг входящих параметров
        $params = $wapkassa->parseRequest($_POST);

        $params['id']; // id платежа в системе wapkassa
        $params['site_id']; // id площадки
        $params['time']; // время оплаты в unixtime
        $params['comm']; // комментарий платежа
        $params['amount']; // сумма платежа
        $params['add']; // массив с допольнительными параметрами
        $keyy = filter2($params['add']['key']);
        if (mb_strlen($keyy) == 32){
        $qqq = $connect->query("SELECT COUNT(*) FROM `rek` WHERE `num` = '$keyy' AND `go` = '1'")->fetchColumn();
        }else{
            $qqq = false;
        }
        // собственный код зачисления платежа на сайте
        if ($qqq) {
        $pay = $connect->prepare("update `users` set `money` = `money` + ? where `id` = ?");
        $stmte = $connect->prepare("INSERT INTO `logs_money` SET `id_user` = ?, `type` = 'plus', `count` = ?, `action` = ?, `time` = ?");
        $pay->execute(array($params['amount'],$params['add']['id']));
        $zaz='Пополнен баланс через WapKassa';
        $time=time();
        $stmte->execute(array($params['add']['id'],$params['amount'],$zaz,$time));
        $qqqq = $connect->prepare("UPDATE `rek` SET `go` = '2' WHERE `num` = ?");
        $qqqq->execute(array(filter2($params[add][key])));
        }else{
            echo 'Об этом даже не думай!';
        }
        // возврат успешной обработки
        echo $wapkassa->successPayment();
    }
} catch (Exception $e) {
    // вывод ошибки
    echo 'Ошибка: ' . $e->getMessage() . PHP_EOL;
}
