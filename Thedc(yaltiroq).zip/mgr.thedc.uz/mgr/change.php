<?php
//-----Подключаем функции-----//
include 'system/func.php';
include 'system/ftp_connect.php';
$d=dir_url('/'.boff(prov(filteroff($_GET['d']))).'/');
ftp_pasv($serv, true);
$lines = ftp_rawlist($serv, "$d");
if (ftp_chdir($serv, $d) == false){
header('Location: /mgr/explode.php');
}else{
echo '<script>function check(form, name, checked){for(var i=0; i<form[name].length; i++){form[name][i].checked=checked;}}</script>';
if (isset($_POST['check']) && count($_POST['check']) < 2){
$title='Расширенный режим';
include 'system/head.php';
title($title);
err('Выбрано мало объектовx'.$_POST['check']);
include 'system/foot.php';
exit();
}
if(!empty($_POST['check']) && !isset($_POST['action'])){
$title='Расширенный режим';
include 'system/head.php';
title($title);
echo '<div class="menu"><form method="post">Всего выбрано: <b>'.count($_POST['check']).'</b><br/>';
foreach($_POST['check'] as $val){
echo'<input type="hidden" name="check[]" value="'.$val.'">';
}
echo '<input type="radio" name="action" value="perenos" checked="checked"> Переместить<br/>
<input type="radio" name="action" value="del"> Удалить<br/>
<input type="radio" name="action" value="chmod"> Права доступа<br/>';
echo '<input class="btn btn-default" type="submit" name="ok" value="Выбрать"></form></div>';
}elseif (!empty($_POST['check']) && !empty($_POST['action'])){
if ($_POST['action'] == 'chmod'){
$title='Права доступа';
include 'system/head.php';
title($title);
if (isset($_POST['ok'])){
$chmod=intval($_POST['chmod']);
if (empty($chmod)){
$err='<div class="menu"><center><font color="red">Не введены права доступа</font></center></div>';
}
elseif (!preg_match('#^([0-9]+){3}$#sU',$chmod) || !is_numeric($chmod) || strlen($chmod) != 3){
$err='<div class="menu"><center><font color="red">Права доступа введены не верно. Пример ввода: 777</font></center></div>';
}
if (!empty($err)){
err($err);
}else{
$array=$_POST['check'];
foreach($array as $val){
$chmd='CHMOD 0'.$chmod.' '.dir_url('/'.$d.'/'.$val);
ftp_site($serv,$chmd);
}
echo '<div class="menu"><center><font color="gren">Команда запущена!</font></center></div>';
}
}
echo '<div class="menu">Выбрано: <b>'.count($_POST['check']).'</b><br/><br/><form method="post">';
foreach($_POST['check'] as $val){
if (ftp_size($serv, dir_url('/'.$d.'/'.$val)) == '-1'){
echo '<img src="/img/mgr/dir.gif" alt="*"> '.$val.'<br/>';
}else{
echo '<img src="/img/mgr/file.gif" alt="*"> '.$val.'<br/>';
}
echo'<input type="hidden" name="check[]" value="'.$val.'">';
}
echo'<input type="hidden" name="action" value="'.$_POST['action'].'">';
echo '<br/>Права доступа:<br/>
<input type="text" name="chmod" maxlength="3" value="777"><br/>
<input class="btn btn-default" type="submit" name="ok" value="Изменить"></form></div>';
}elseif($_POST['action'] == 'perenos'){
$title='Перемещение объектов';
include 'system/head.php';
title($title);
foreach($_POST['check'] as $dirz){
$outs.=(ftp_size($serv, dir_url('/'.$d.'/'.$dirz)) == '-1'?'<img src="/img/mgr/dir.gif" alt="*"> '.prov($dirz).'<br/>':'<img src="/img/mgr/file.gif" alt="*"> '.prov($dirz).'<br/>');
}
if (isset($_POST['ok'])){
$put=prov($_POST['put']);
if (!empty($put)){
$put=dir_url('/'.$put.'/');
$verh=dir_url('/'.verh2(verh2($d)).'/');
}
if (empty($put)){
$err='<div class="menu"><center><font color="red">Не введён путь перемещения</font></center></div>';
}
elseif (!preg_match('#^[A-z0-9_\-\/\.]+$#sU',$put)){
$err='<div class="menu"><center><font color="red">Обнаружены запрещенные символы. Разрешено: A-z0-9_-/.</font></center></div>';
}
//elseif ($put == $verh){$err='<div class="error">Выбранные объекты, и так находятся в этой директории</div>';
//}
elseif (ftp_nlist($serv, $put) == false){
$err='<div class="menu"><center><font color="red">Директория не существует</font></center></div>';
}
if (!empty($err)){
err($err);
}else{
foreach($_POST['check'] as $name){
if (ftp_rename($serv, dir_url('/'.$d.'/'.$name), dir_url('/'.$put.'/'.$name))) {
}
}
echo '<div class="menu"><center><font color="gren">Перемещение запущено!</font></center></div>';
}
}
echo '<div class="menu">Выбрано: <b>'.count($_POST['check']).'</b><br/><br/><form method="post">';
echo $outs;
foreach($_POST['check'] as $val){
echo '<input type="hidden" name="check[]" value="'.$val.'">';
}
$value=dir_url('/'.verh2(verh2(verh2($d))).'/');
echo '<input type="hidden" name="action" value="'.$_POST['action'].'"><br/>Путь перемещения:<br/><input type="text" name="put" value="'.$value.'"><br/><input class="btn btn-default" type="submit" name="ok" value="Сохранить"></form></div>';
}elseif($_POST['action'] == "del"){
$title='Удаление объектов';
include 'system/head.php';
title($title);
echo '<div class="menu">Выбрано: <b>'.count($_POST['check']).'</b><br/></div>';
echo '<div class="menu"><center><font color="gren"><b>Удаление запущено!</b></font></center><br/><br/></div><div class="main">';
foreach($_POST['check'] as $dirz){
if (ftp_size($serv, dir_url('/'.$d.'/'.$dirz)) == '-1'){
echo '<img src="/img/mgr/dir.gif" alt="*"> '.$dirz.'<br/>';
}else{
echo '<img src="/img/mgr/file.gif" alt="*"> '.$dirz.'<br/>';
}
}
foreach($_POST['check'] as $val){
$delete=dir_url('/'.$d.'/'.$val);
if (ftp_size($serv, $delete) == '-1'){
rdir($serv, $delete, $delete);
ftp_rmdir($serv, $delete);
}else{
ftp_delete($serv, $delete);
}
}
echo '</div>';
}
}elseif(!isset($_POST['check']) && !isset($_POST['action'])){
$title='Расширенный режим';
include 'system/head.php';
title($title);
echo '<div class="menu"><form method="post">';
$cnt_dir=0;
for($i=0; $i<count($lines); $i++) {
  $name=preg_replace("~([^\s]*[\s]*){8}\s{1}(.*)~m","\\2",$lines[$i]);
if ($name != '.' && $name != '..' && !preg_match('/->/i',$name)){
if (ftp_size($serv, $d.'/'.$name) == '-1'){
echo '<input type="checkbox" name="check[]" value="'.$name.'"> <img src="/img/mgr/dir.gif" alt="*"> '.$name.'<br>';
$cnt_dir++;
 }
 }
 }
$cnt_files=0;
for($i=0; $i<count($lines); $i++){
$name=preg_replace("~([^\s]*[\s]*){8}\s{1}(.*)~m","\\2",$lines[$i]);
if ($name != '.' && $name != '..' && !preg_match('/->/i',$name)){
if (ftp_size($serv, $d.'/'.$name) != '-1'){
echo '<input type="checkbox" name="check[]" value="'.$name.'"> <img src="/img/mgr/file.gif" alt="*"> '.$name.' '.sizer(ftp_size($serv, $d.'/'.$name)).'<br/>';
$cnt_files++;
}
}
}
if ($cnt_files == 0 && $cnt_dir == 0){
echo '</div><div class="menu"><center><font color="red">Папка пуста</font></center></div>';
include 'system/foot.php';
exit();
}
echo '<br/><input type="checkbox" value="check" onclick="check(this.form,\'check[]\',this.checked)"> Отметить всё<br/><input class="btn btn-default" type="submit" name="ok" value="Выбрать"></form></div><div class="title">Папок: '.$cnt_dir.' / Файлов: '.$cnt_files.'</div>';
 }
}
echo '<div class="menu">&laquo; <a href="/mgr/explode.php?d='.bon($d).'">Назад</a></div>';
include'system/foot.php';
?>