<?php
$title='Планировщик (CRON)';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
    $ontarif = $connect->prepare("select * from `tarifs_hosting` where `id` = ?");
    $ontarif->execute(array($user['id_tarif']));
    $ustarif = $ontarif->fetch(PDO::FETCH_LAZY);
    $server = $connect->query("SELECT * FROM `servers` WHERE `id` = '".abs(intval($ustarif[id_server]))."'");
    $server = $server->fetch(PDO::FETCH_LAZY);
echo '<div class="title">Новая CRON задача</div>';	
//echo 'https://'.$server->ip.'/ispmgr?func=scheduler.edit&out=xml&authinfo=' . $user['isp_login'] . ':' . $user['isp_pass'].' ';
    $content = api_query('https://'.$server->ip.'/ispmgr?func=scheduler.edit&out=xml&authinfo=' . $user['isp_login'] . ':' . $user['isp_pass']);
    $parse_xml1 = simplexml_load_string($content);
    if (empty($_POST['submit'])) {
        echo '<div class="menu"><form action="/cron/add" method="post">' . "\n";

  echo '<input placeholder="URL" name="command" type="text"> (Пример: http://test.ru/test.php)<br/>'; 
  echo '<input  placeholder="Описание" name="description" type="text"> (Пример: My Site Cron1)<br/>'; 
  echo '<b>Выполнить каждый</b>:<br/><select size="1" name="pro">
        <option value="5">1 минут</option>
        <option value="6">5 минут</option>
        <option value="7">15 минут</option>
        <option value="8">30 минут</option>
        <option value="1">каждый час</option>
        <option value="2">ежедневно</option>
        <option value="3">еженедельно</option>
        <option value="4">ежемесячно</option>
        </select><br/>';
        echo '<input class="btn btn-default" name="submit" type="submit" value="Добавить" />' . "\n";
        echo '</form></div>' . "\n";
        echo '<div class="menu"><a href="/cron">&laquo; Назад</a></div>' . "\n";
       
     } else {
         $cmmon='/usr/bin/wget -O /dev/null '. $_POST['command'];
         if (filter($_POST['pro']==1)) {$mm='every_hour';}
         elseif (filter($_POST['pro']==2)) {$mm='every_day';}
         elseif (filter($_POST['pro']==3)) {$mm='every_week';}
         elseif (filter($_POST['pro']==4)) {$mm='every_month';}
         elseif (filter($_POST['pro']==5)) {$mm='*/1';}
         elseif (filter($_POST['pro']==6)) {$mm='*/5';}
         elseif (filter($_POST['pro']==7)) {$mm='*/15';}
         elseif (filter($_POST['pro']==8)) {$mm='*/30';}
         $m1='*';
         $m2='*';
         $m3='*';
         $m4='*';
		// Фильтрация
		$mailto = filter($_POST['mailto']);
		if($_POST['pro'] >= 5){
		$content = api_query('https://'.$server->ip.'/ispmgr?func=scheduler.edit&schedule_type=type_expert&mailto='.$mailto.'&input_hour=' . $m1 . '&input_min=' . $mm . '&input_dmonth=' . $m2 . '&input_month=' . $m3 . '&input_dweek=' . $m4 . '&command=' . urlencode($cmmon) . '&description=' . urlencode($_POST['description']) . '&out=xml&sok=ok&authinfo=' . $user['isp_login'] . ':' . $user['isp_pass']);
		}else{
        $content = api_query('https://'.$server->ip.'/ispmgr?func=scheduler.edit&schedule_type=type_basic&command='.urlencode($cmmon).'&mailto='.$mailto.'&run_every='.$mm.'&description=' . urlencode($_POST['description']) . '&out=xml&sok=ok&authinfo=' . $user['isp_login'] . ':' . $user['isp_pass']);
		}
		$parse_xml = simplexml_load_string($content);
        if (isset($parse_xml->ok)) {
            echo '<div class="menu">' . "\n";
            echo '<center><font color="gren">CRON задача успешно добавлена!</font></center>' . "\n";
			echo '</div>' . "\n";
            echo '<div class="menu"><a href="/cron">Продолжить</a></div>' . "\n";
        } else {
            echo '<div class="menu">' . "\n";
            //echo print_r($content);
		    echo '<center><font color="red">Ошибка при добавлении CRON задачи!</font></div>' . "\n";
			echo '</div>' . "\n";
            echo '<div class="menu"><a href="/cron">Продолжить</a></div>' . "\n";
        }
    }
	  
} else {
header('Location: /');
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>