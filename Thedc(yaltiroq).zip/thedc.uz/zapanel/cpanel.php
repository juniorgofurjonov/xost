<?php
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
switch($act) {
default:
$auth_succ = $connect->query("SELECT COUNT(*) FROM `authlog` WHERE `uid` = '$user->id' AND `status` = '1'")->fetchColumn();
$auth_fail = $connect->query("SELECT COUNT(*) FROM `authlog` WHERE `uid` = '$user->id' AND `status` = '0'")->fetchColumn();
$or_host = $connect->query("SELECT COUNT(*) FROM `orders_hosting` WHERE `id_user` = '$user->id'")->fetchColumn();
$log_monp = $connect->query("SELECT COUNT(*) FROM `logs_money` WHERE `id_user` = '$user->id' AND `type` = 'plus'")->fetchColumn();
$log_monm = $connect->query("SELECT COUNT(*) FROM `logs_money` WHERE `id_user` = '$user->id' AND `type` = 'minus'")->fetchColumn();
$new_admt = $connect->query("SELECT COUNT(*) FROM `tickets` WHERE `read_adm` = '0'")->fetchColumn();
$admt1 = $connect->query("SELECT COUNT(*) FROM `tickets` ")->fetchColumn();
if ($new_admt >= 1) {$newta='[<font color="red">+'.$new_admt.'</font>]';}else{$newta='';}
echo '<div class="title">Кабинет</div>';
echo '<div class="menu">&bull; <a href="/user/listauth"> Avtorizatsiya tarixi [<font color="gren">'.$auth_succ.'</font>/<font color="red">'.$auth_fail.'</font>]</a></div>';
echo '<div class="menu">&bull; <a href="/user/moneyhistory"> Mablag`lar harakati [<font color="gren">'.$log_monp.'</font>/<font color="red">'.$log_monm.'</font>]</a></div>';
echo '<div class="menu">&bull; <a href="/user/tg"> Telegram akaunt ['.(!empty($user['tg_id']) ? '<font color="gren">подключен</font>' : '<font color="red">не подключен</font>').']</a></div>';
echo '<div class="menu">&bull; <a href="/user/sett"> Parolni o`zgartirish</a></div>';
echo '<div class="menu">&bull; <a href="/user/email"> E-Mailni o`zgartirish</a></div>';
echo '<div class="menu">&bull; <a href="/pay/"> Balansni to`ldirish</a></div>';
echo '<div class="menu">&bull; <a href="/user/exit"> Chiqish</a></div>';

if ($adm_id == 5) {
echo '<div class="title"> Admin uchun</div>';
$allon=$count_online_user + $count_online_guest;
echo '<div class="menu">&bull; <a href="/adm/tickets"> Админ | Тикеты ['.$admt1.'] '.$newta.'</a></div>';
echo '<div class="menu">&bull; <a href="/adm"> ADMIN Boshqaruv paneli ['.$allon.'] ('.$count_online_user.'/'.$count_online_guest.')</a></div>';
}
break;
case 'settings':
echo '<div class="title"> Parolni o`zgartirish</div>';

$error = '';
			
if (isset($_POST['pass']) && isset($_POST['new_pass']) && isset($_POST['last_pass'])) {
if (empty($_POST['pass'])) {
$error.= 'Hozirgi parolingizni kiriting!<br/>';
}
elseif (md5(md5($_POST['pass'])) != $user['pass']) {
$error.= 'Noto`g`ri parol noto`g`ri kiritildi!<br/>';
}
elseif (empty($_POST['new_pass'])) {
$error.= 'Yangi parolni kiriting!<br/>';
}
elseif (mb_strlen($_POST['new_pass']) < 3 or mb_strlen($_POST['new_pass']) > 15) {
$error.= 'Yangi parol 3 dan 15 tagacha belgidan iborat bo`lishi kerak!<br/>';
}
elseif (empty($_POST['last_pass'])) {
$error.= 'Tasdiqlash parolini kiriting!<br/>';
}
elseif ($_POST['last_pass'] != $_POST['new_pass']) {
$error.= 'Tasdiqlash paroli noto‘g‘ri kiritildi!<br/>';
}
elseif (md5(md5($_POST['new_pass'])) == $user['pass']) {
$error.= 'Sizda ushbu parol yoqilgan.!<br/>';
}
if ($error) {
echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
} else {
$stmt = $connect->prepare("update `users` set `pass` = ? where `login` = ? limit 1");
if ($stmt->execute(array(md5(md5($_POST['new_pass'])), $user['login']))) {
setcookie('pass', md5(md5($_POST['new_pass'])), time() + 3600 * 24 * 30);
echo '<div class="menu"><center><font color="gren">Parol muvaffaqiyatli o`zgartirildi!</font></center></div><meta http-equiv="Refresh" content="3; "/>';
} else {
echo '<div class="menu"><center><font color="red">Xato ro`y berdi!</font></center></div>';
}
}
}
echo '<div class="menu"><form action="" method="post">Haqiqiy parol:<br /><input type="password" name="pass" maxlength="15"/><br/>Yangi parol:<br /><input type="password" name="new_pass" maxlength="15"/><br/>Yangi parolni takrorlang:<br /><input type="password" name="last_pass" maxlength="15"/><br/><input class="btn btn-default" type="submit" value="Tahrirlash"/></form></div>';
break; 
case 'enter':
if (isset($_POST['submit'])) {
header('location: /user/menu');
}
echo '<div class="title">Kirish</div>';
echo '<div class="menu">IP: '.filter($_SERVER['REMOTE_ADDR']).'<br/>
UA: '.filter($user['ua']).'<br/>
Время: '.date('d.m.Y H:i', $user['lasttime']).'</div>
<div class="menu"><form action="" method="post"><input class="btn btn-default" type="submit" name="submit" value="Hisobimga kirish"></form>
Автологин:<br/><input type="text" value="'.ROOT.'/auth?login='.filter($user['login']).'&pass=ВАШ_ПАРОЛЬ"/></div>';
break;
case 'exit':
if ($set['close'] == 1) {

        if (isset($_POST['exit'])) {

            $reset_auth = $connect->prepare("update `authlog` set `status` = ? where `uid` = ? and `key` = ?");

            $reset_auth->execute(array(0, $user['id'], $authash));

            setcookie('user_id', null, time() - 3600, '/');
            setcookie('pass', null, time() - 3600, '/');
            setcookie('auth', null, time() - 3600, '/');

            header('Location: /');

        }
        echo '<div class="title">Akauntdan chiqish</div>';
        echo '<div class="menu"><form action="" method="POST">
        Siz rostdan ham akauntdan chiqmoqchimisiz?<br/>
        <input type="submit" class="btn btn-default" name="exit" value="Ha, chiqmoqchiman">
        </form></div>';

    } else{
        echo '<div class="err">Siz sayt yopiqligida tizimdan chiqa olmaysiz!</div>';

}
break;

}
} else {
header('Location: /auth');}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>