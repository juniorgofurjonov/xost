<?php
// baza ma'lumotlari!
DEFINE('DB_HOST','localhost');
DEFINE('DB_USER','abdumutal');
DEFINE('DB_PASS','L3p7G8u0');
DEFINE('DB_NAME','abdumutal');

/*DEFINE('DB_HOST','localhost');
DEFINE('DB_USER','thedcuz');
DEFINE('DB_PASS','D4t2E8g9');
DEFINE('DB_NAME','thedcuz');
*/
?>