<?php
$title = 'Админ || Тикеты';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if ($adm_id == 5) {
switch($act) {
default:
if(isset($_GET['cl_tik']))
{
$sql4 = $connect->prepare("UPDATE `tickets` SET `close` = ?");
$sql4->execute(array(1));
header('Location:/adm/tickets?');
exit();
}
$_GET['id'] = (isset($_GET['id']) ? (int) abs($_GET['id']) : null);
$q1 = $connect->prepare("SELECT * FROM `tickets` WHERE `id` = ? LIMIT 1");
$q1->execute(array(val($_GET['id'])));
$q2 = $connect->prepare("SELECT * FROM `tickets` WHERE `id` = ? AND `read_adm` = ? LIMIT 1");
$q2->execute(array(val($_GET['id']),0));
if(isset($_GET['id']))
{
if($q1->rowCount()==0)
{
header('Location:/adm/tickets?');
}
elseif($q2->rowCount()>0)
{
$connect->query("UPDATE `tickets` SET `read_adm` = '1' WHERE `id` = '".val($_GET['id'])."'");
header('Location:/adm/tickets/id/'.val($_GET['id']).'');
}

$ticket = $connect->prepare("SELECT * FROM `tickets` WHERE `id` = ?");
$ticket->execute(array(val($_GET['id'])));
$ticket = $ticket->fetch(PDO::FETCH_LAZY);
@$otv = val($_GET['otv']);
if(isset($_POST['submit']) && $ticket->close=='0')
{
$msg = $_POST['msg'];

if(strlen($_POST['msg']) < 1)
{
$error = '<div class="err">Слишком короткое сообщение.</div>';
}
elseif(strlen($_POST['msg']) > 5000)
{
$error = '<div class="err">Слишком длинное сообщение.</div>';
}
$filename = $_FILES['file']['name'];
$filesize = $_FILES['file']['size'];
$ext = strtolower(strrchr($_FILES['file']['name'], '.'));
$form = array('.png', '.jpg', '.jpeg', '.gif');
if (!empty($filename)) {
if ($filesize > (1024 * 3 * 1024)) {
$error .= '<div class="err"> Максимальный размер файла 3 Mb!</div>';
} elseif ($filesize == 0) {
$error .= '<div class="err"> Маленький размер файла!</div>';
} elseif (preg_match('/(\.php|\.pl|\.htaccess|\.js)/i', $_FILES['file']['name']) || !in_array($ext, $form)) {
$error .= '<div class="err"> Запрещеный формат файла!</div>';
}
}
if (!empty($_FILES['file']['name'])) {
$files = 'image_admins_'.time().$ext;
} else {
$files = '';
}
if (empty($error)) {

if (!empty($_FILES['file']['name'])) {
copy($_FILES['file']['tmp_name'], $_SERVER['DOCUMENT_ROOT'].'/image/tikets/'.$files);
}
$time=time();	
$sql1 = $connect->prepare("INSERT INTO `tickets_msg` SET `id_ticket` = ?, `id_user` = ?, `msg` = ?, `time` = ?, `file` = ?");
$sql1->execute(array($ticket->id,$user->id,$msg,$time,$files));
$tgnot=user($ticket->id_user);
if (isset($tgnot['tg_id'])) {
$tgmsg='
 Здравствуйте, '.$tgnot['login'].'
У вас новый ответ в тикет!

ID тикета: #'.$ticket->id.'
Сообщиние оператор: '.$msg;
    tgmsg($tgnot['tg_id'], filteroff($tgmsg), '');
}
$sql2 = $connect->prepare("UPDATE `tickets` SET `read_user` = ?, `time_update` = ? WHERE `id` = ?");
$sql2->execute(array(0,$time,$ticket->id));
header('Location:/adm/tickets/id/'.val($ticket->id).'');
}
}
elseif(isset($_POST['open']))
{
$sql3 = $connect->prepare("UPDATE `tickets` SET `close` = ? WHERE `id` = ?");
$sql3->execute(array(0,$ticket->id));
header('Location:/adm/tickets/id/'.val($ticket->id).'');
}
elseif(isset($_POST['close']))
{
$sql4 = $connect->prepare("UPDATE `tickets` SET `close` = ? WHERE `id` = ?");
$sql4->execute(array(1,$ticket->id));
header('Location:/adm/tickets/id/'.val($ticket->id).'');
}
echo '<div class="title">Название тикета: '.$ticket->name.'</div><div class="menu"><b>ID тикета</b>: '.$ticket->id.'';
echo '<br /><b>Категория</b>: ';
if($ticket->id_kat==1)echo 'Финансовый отдел [RU]';
elseif($ticket->id_kat==2)echo 'Финансовый отдел [UZ]';
elseif($ticket->id_kat==3)echo 'Технический отдел [RU]';
elseif($ticket->id_kat==4)echo 'Технический отдел [UZ]';
else echo 'Не указана</font>';
if(isset($error))echo $error;
if($ticket->id_user!=$user->id)
	{
		$ank_avt = $connect->prepare("SELECT * FROM `users` WHERE `id` = ?");
		$ank_avt->execute(array($ticket->id_user));
		$ank_avt = $ank_avt->fetch(PDO::FETCH_LAZY);
	}
else 
	{
		$ank_avt = $user;
	}
$user_host = $connect->query("SELECT COUNT(*) FROM `orders_hosting` WHERE `id_user` = '$ank_avt->id'")->fetchColumn();
$user_host_off = $connect->query("SELECT COUNT(*) FROM `orders_hosting` WHERE `id_user` = '$ank_avt->id' AND `activ` = '2'")->fetchColumn();
echo '<br/>
							<b>Логин</b>: <a href="/adm/users/id/'.$ank_avt->id.'">'.ulogin($ank_avt->id).'</a> '.online(uid($ank_avt->login)).' ('.$ank_avt->id.') 
							<br/><b>Время создан тикет</b>: '.vremja($ticket->time).' <br/>
							<b>Читаль тикет ?</b> '.($ticket->read_user ? '<font color="gren">Да</font>' : '<font color="red">Нет</font>').'</div><div class="menu">
							<b>Информатция о клиент!</b> <br/>';
							$ontarif = $connect->prepare("select * from `tarifs_hosting` where `id` = ?");
$ontarif->execute(array($ank_avt['id_tarif']));
$ustarif = $ontarif->fetch(PDO::FETCH_LAZY);
$usm=$ank_avt->money;
$tcm=$ustarif['price_day'];
if ($tcm == 0) {$k='0';}else{
for ($k=0;$tcm <=$usm;$k++){
    $usm=$usm-$tcm;
}}
if ($k >= 1) {
    $allc = 86400 * $k;
}else{$allc='0';}
if ($ank_avt['activ'] >= 2) {
echo '<b>Осталось дней</b>: '.order_day(($ank_avt['time_work'] + $allc)).' (Активен до: '.vremja(($ank_avt['time_work'] + $allc)).' )<br/>
'.(order_day($ank_avt['time_work'],true) < 0.01 ? '<font color="red"><b>До сброс аккаунт осталось</b>: '.order_day(($ank_avt['time_work'] + (84600 * 7))).' дней. </font><br/>' : '').' ';}
echo 'Тариф: <b>'.$ustarif['name'].' ('.$ustarif['price_day'].' руб/день)</b><br/>';
if ($ank_avt[activ]==0) {$c1='<font color="red">аккаунт не активирован!</font> (0)';}
if ($ank_avt[activ]==1) {$c1='<font color="red">аккаунт не активирован!</font>(1)';}
if ($ank_avt[activ]==2) {$c1='<font color="gren">аккаунт Активен!</font>(2)';}
if ($ank_avt[activ]==3) {$c1='<font color="red">аккаунт отключен!</font>(3)';}
if ($ank_avt[activ]==4) {$c1='<font color="red">аккаунт блокирован!</font>(4)';}
if (empty($c1)) {$c1='Error';}
            echo '
            <b>Баланс</b>: '.$ank_avt['money'].' Руб<br/>
            <b>Активность</b>: ['.$c1.']<br/>';
echo '</div><div class="menu">';
echo '<b>Сообщиние</b>: '.nl2br(smiles(bb(bblinks($ticket->msg)))).'
						';
			echo '<form method="post"><input class="btn btn-default" type="submit" name="'.($ticket->close=='0'?'close':'open').'" value="'.($ticket->close=='0'?'Закрыть тикет':'Открыть тикет').'"/></form>';
echo '</div>';
if($ticket->close=='0')
{
    include($_SERVER["DOCUMENT_ROOT"]."/inc/smiles_bb.php");
echo '<div class="menu">';
echo '<form method="post" enctype="multipart/form-data">';
echo 'Сообщение:<br/> <textarea rows="5" cols="40" name="msg" required>';
if($otv != 0) echo '[b]'.ulogin($otv).'[/b], ';
echo ''.(isset($_POST['msg'])?''.filter($_POST['msg']).'':NULL).'</textarea><br/>';
echo '<b>Прикрепить скриншот: </b>
<input type="file" name="file"/>';
echo '<br/><input class="btn btn-default" type="submit" name="submit" value="Отправить"/>  <a href="">[Обновить]</a></form>';
echo '</div>';
}

$k_post = $connect->prepare("SELECT * FROM `tickets_msg` WHERE `id_ticket` = ?");
$k_post->execute(array($ticket->id));
$k_post = $k_post->rowCount();
$k_page = k_page($k_post, 10);
$page = page($k_page);
$start = 10*$page-10;
$q = $connect->prepare("SELECT * FROM `tickets_msg` WHERE `id_ticket` = ? ORDER BY `time` DESC LIMIT $start, 10");
$q->execute(array($ticket->id));
while ($msg = $q->fetch(PDO::FETCH_LAZY))
{
if($msg->id_user!=$user->id)
	{
		$ank_m = $connect->prepare("SELECT * FROM `users` WHERE `id` = ?");
		$ank_m->execute(array($msg->id_user));
		$ank_m = $ank_m->fetch(PDO::FETCH_LAZY);
	}
else 
	{
		$ank_m = $user;
	}
	if ($ank_m['admin'] >= 1) {$c1='adm';}else{$c1='user';}
echo '
						<div class="menu"><img src="/inc/style/img/'.$c1.'.png" alt="'.filter($ank_m->login).'"> <a>'.filter($ank_m->login).'</a> '.online(uid($ank_m->login)).' ['.vremja($msg->time).'] '.(($ank_m->id != $user['id']) && $user['ban'] == 0 ? '[<a href="?id='.$ticket->id.'&otv='.$ank_m->id.'">Отв</a>]' : '').'
						<div class="st_1"></div><div class="st_2">'.nl2br(smiles(bb(bblinks($msg->msg)))).'
					';

if($msg->file) {
	?>
<br />	<b>Изображения :</b><br />
	<a href = "/image/tikets/<?php echo $msg->file;?>">
		<img width="140" height="100" src = "/image/tikets/<?php echo $msg->file;?>">
	</a>
	<?php
}
echo '</div></div>';
}
echo '<div class="menu">&bull; <a href="/adm/tickets/'.($ticket->close=='0' ? '' : 'close/').'">Назад</a></div>';
if ($k_page  > 1)str('/adm/tickets/id/'.$ticket->id, $k_page, $page);
}else{

echo '<div class="title">Открытые тикеты</div>';

$k_post = $connect->query("SELECT * FROM `tickets` WHERE `close` = '0'");
$k_post = $k_post->rowCount();
if($k_post == 0)
{
echo $div->post;
echo '<div class="menu"><center><font color="red">Открытых тикетов нет.</font></center></div>';
echo $div->off;
}
$k_page = k_page($k_post, 10);
$page = page($k_page);
$start = 10*$page-10;

$q = $connect->query("SELECT * FROM `tickets` WHERE `close` = '0' ORDER BY `read_adm` ASC, `time_update` DESC LIMIT $start, 10");
$closet = $connect->prepare("SELECT COUNT(*) FROM `tickets` WHERE `close` = ?");
$closet->execute(array(1));
$closet = $closet->fetchColumn();
while ($ticket = $q->fetch(PDO::FETCH_LAZY))
{
echo '<div class="menu">';
echo '<a href="/adm/tickets/id/'.$ticket->id.'">';
echo '
<b>#'.$ticket->id.')</b> '.$ticket->name.' </a>('.filter(ulogin($ticket->id_user)).') ('.vremja($ticket->time).')
	'.($ticket->read_adm==0?'[<font color="red">New</font>]':'').'<br/>';
echo '</div>';}
echo '<div class="menu">&bull;<a href="/adm/tickets/close"> Закрытые тикеты ['.$closet.']</a></div>';
if ($k_page  > 1)str('/adm/tickets?', $k_page, $page);
}
break;
case 'close':
echo '<div class="title">Закрытые тикеты</div>';

$k_post = $connect->query("SELECT * FROM `tickets` WHERE `close` = '1'");
$k_post = $k_post->rowCount();
if($k_post == 0)
{
echo $div->post;
echo '<div class="menu"><center><font color="red">Закрытые тикетов нет.</font></center></div>';
echo $div->off;
}
$k_page = k_page($k_post, 10);
$page = page($k_page);
$start = 10*$page-10;

$q = $connect->query("SELECT * FROM `tickets` WHERE `close` = '1' ORDER BY `read_adm` ASC, `time_update` DESC LIMIT $start, 10");
while ($ticket = $q->fetch(PDO::FETCH_LAZY))
{
echo '<div class="menu">';
echo '<a href="/adm/tickets/id/'.$ticket->id.'">';
echo '
<b>#'.$ticket->id.')</b> '.$ticket->name.' </a>('.filter(ulogin($ticket->id_user)).') ('.vremja($ticket->time).')
	'.($ticket->read_adm==0?'[<font color="red">New</font>]':'').'<br/>';
echo '</div>';}
echo '<div class="menu">&bull;<a href="/adm/tickets"> Назад</a></div>';
if ($k_page  > 1)str('/adm/tickets/close?', $k_page, $page);
break;




}echo '<div class="menu">&bull;<a href="/adm"> Панель управления</a></div>';
} else {
header ('location: /?404');
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>