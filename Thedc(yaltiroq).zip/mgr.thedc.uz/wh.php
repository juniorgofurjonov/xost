<?php
$title = 'TheDC.uz | Sayt boshqaruvi!';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
 echo '<div class="title">WebHook Sozlash</div>';
?>
<html>

<head>


  <script src="https://unpkg.com/vue/dist/vue.js"></script>
</head>

<body>
    
  <div class="menu">
    
    <div id="app" class="section">
          <font align="center">
      <form :action="set_webhook" method="post" enctype="multipart/form-data">
     <p class="control">
      <label class="label">Tokenni kiriting</label>
        </p>
        <p class="control">
          <input class="input" type="text" v-model="token" />
        </p>
        <p class="control">
         <label class="label">Host URL ni kiriting ( "https://" kerak emas )</label>
        </p>
        <p class="control">
          <input class="input" type="text" v-model="host" />
        </p>
        
        <div class="control is-grouped">
          <p class="control">
            <button class="button is-primary" name="submit">Webhookni sozlash</button>
          </p>
       
         </font>
        </div>
    </div>
  </div>
  <script>
    new Vue({
      el: '#app',
      data: {
        token: '',
        host: '',
      },
      computed: {
        get_webhook_info: function () {
          return 'https://api.telegram.org/bot' + this.token + '/getwebhookinfo'
        },
        set_webhook: function () {
          return 'https://api.telegram.org/bot' + this.token + '/setwebhook?url=' + this.host
        },
      }
    }

    )
  </script>
</body>

</html>
<?
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>