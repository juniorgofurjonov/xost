<?php
$title = 'Lotereya';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
echo '<div class="title">Lotereya</div>';
if (isset($_POST['submit'])) {
$err = '';
$stmt = $connect->prepare("select count(`id`) from `loto` where `idu` = ?");
$stmt->execute(array($user['id']));
$num = $stmt->fetchColumn();
if ($num > 0) {
$err.= 'Siz allaqachon bilet sotib olgansiz!<br/>';
}
if ($user['money'] < 1) {
$err.= 'Mablag` yetarli emas!<br/>';
}
if ($err) {
echo '<div class="menu"><center><font color="red">'.$err.'</font></center></div>'; 
} else {
$stmt1 = $connect->prepare("update `users` set `money` = `money` - '1' where `id` = ?");
$stmt2 = $connect->prepare("insert into `loto` set `idu` = ?");
$cena='2';
$zaz='Lotto biletni buyurtma qilish';
$time=time();
$stmte = $connect->prepare("INSERT INTO `logs_money` SET `id_user` = ?, `type` = 'minus', `count` = ?, `action` = ?, `time` = ?");
if ($stmt1->execute(array($user['id'])) && $stmt2->execute(array($user['id'])) && $stmte->execute(array($user['id'],$cena,$zaz,$time))) {
echo '<div class="menu">Bilet muvaffaqiyatli sotib olindi!</div>';
header('Refresh: 1');
} else {
echo '<div class="menu"><center><font color="red">Xatolik yuz berdi!</font></center></div>';
}
}
}
echo '<div class="menu">Jek-pod: '.$loto_count.' руб.<br/>Foydalanuvchlar jalb qilingan: '.$loto_count.'<br/>Maks. ishtirokchilar soni: '.val($set['loto']).'</div>';
$stmt = $connect->prepare("select count(`id`) from `loto` where `idu` = ?");
$stmt->execute(array($user['id']));
$num = $stmt->fetchColumn();

if ($num == 0) {
echo '<div class="menu"><form action="" method="post"><input class="btn btn-default" type="submit" name="submit" value="Bilet sotib olish (2 rub.)" /></form></div>';
} else {
$stmt = $connect->prepare("select * from `loto` where `idu` = '".$user['id']."'");
$stmt->execute(array($user['id']));
$loto = $stmt->fetch(PDO::FETCH_LAZY);
echo '<div class="menu">Lotereya tugashini kuting! Sizning biletingiz — '.val($loto['id']).'.</div>'; 
}
} else {
header('Location: /auth');} 
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
 ?>