<?php
$title = 'Parolni tiklash';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == false) {
echo '<div class="title">Parolni tiklash</div>';
$_SESSION['rand_pass'] = gen_pass();
if (isset($_GET['sess'])){
$stmtab = $connect->prepare("select count(*) from `forgot` where `sess` = ?");
$stmtab->execute(array($_GET['sess']));
$num = $stmtab->fetchColumn();
$error='';
if ($num == 0) {
$error= 'Sizning seansingiz eskirgan yoki yo`q!';
header( "refresh:3;url=/" );
}
if ($error) {
echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
} else {
$forgota = $connect->prepare("SELECT * FROM `forgot` WHERE `sess` = ?");
$forgota->execute(array($_GET['sess']));
$forgot = $forgota->fetch(PDO::FETCH_LAZY);
$stmt = $connect->prepare("update `users` set `pass` = ? where `login` = ? limit 1");
if ($stmt->execute(array(md5(md5($_SESSION['rand_pass'])), $forgot['login']))) {
mailto($forgot['email'], 'TheDC.uz parolini tiklash',
'Siz parolni tiklashni so`radingiz!<br/>
Sizning yangi parolingiz: '.$_SESSION['rand_pass'].'<br/> Avtologin uchun havola: '.ROOT.'/auth?login='.$forgot['login'].'&pass='.$_SESSION['rand_pass'].'<br/><br/>Hurmat bilan, Administrator #Bek TheDC.uz',
$set['mail']);
$delsess = $connect->prepare("delete from `forgot` where `id` = ? limit 1");
$delsess->execute(array($forgot['id']));
echo '<div class="menu"><center><font color="gren">Sizning parolingiz elektron pochtangizga yuborildi.</font></center></div>';
header( "refresh:3;url=/" );
} else {
echo '<div class="menu"><center><font color="red">Parolni tiklashda xato!</font></center></div>';
}
}
}
if (empty($_GET['sess'])){
echo '<div class="menu"><center><font color="red">Seans yo‘q</font></center></div>';
    header( "refresh:3;url=/" );
}
} else {
header('Location: /user/menu');
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>