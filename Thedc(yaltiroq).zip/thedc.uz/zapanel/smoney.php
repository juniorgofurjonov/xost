<?php
$title = 'Pul o`tkazish';
require_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
$ack = '1';
if (isset($active) && $ack) {
    echo '<div class="title">Pul o`tkazish</div>';
    if ($user['accesstosm'] == 2){

    if (isset($_SESSION['send_summ']) && isset($_SESSION['send_login']) && isset($_SESSION['send_key'])) {

        if ($_SESSION['send_login'] == $user['login']) {

            unset($_SESSION['send_summ'], $_SESSION['send_login'], $_SESSION['send_key']);

            header('Location: /service/sendmoney');

        } else {

            if (isset($_POST['cancel'])) {

                unset($_SESSION['send_summ'], $_SESSION['send_login'], $_SESSION['send_key']);

                header('Location: /service/sendmoney');

            }
            elseif (isset($_POST['send_verify'])) {

                $error = '';

                if (empty($_POST['send_key'])) {
                    $error.= 'Tasdiqlash kodini kiriting!<br/>';
                }
                elseif ($_POST['send_key'] != $_SESSION['send_key']) {
                    $error.= 'Tasdiqlash kodi noto‘g‘ri!<br/>';
                }elseif (!preg_match("#^[0-9]{1,15}$#i", $_SESSION['send_summ'])){
                    $error.= 'OOPS! Faqat Integer!<br/>';
                }
                if ($error) {
                    echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
                } else {
                    if ($user['money'] > $_SESSION['send_summ']){
                    $summ = p($_SESSION['send_summ'], $amx['amx']['procent']);
                    $smm = $connect->prepare("update `users` set `money` = `money` - ? where `login` = ?");
                    $smmh = $connect->prepare("INSERT INTO `logs_money` SET `id_user` = ?, `type` = 'minus', `count` = ?, `action` = ?, `time` = ?");
                    $zaz='Siz ushbu login ga pul o`tkazdingiz <b>'.filter2($_SESSION['send_login']).'</b>';
                    if ($smm->execute(array($_SESSION['send_summ'], $user['login'])) && $smmh->execute(array($user['id'], $_SESSION['send_summ'], $zaz, $time))){
                       $smp = $connect->prepare("update `users` set `money` = `money` + ? where `login` = ?");
                       $smph = $connect->prepare("INSERT INTO `logs_money` SET `id_user` = ?, `type` = 'plus', `count` = ?, `action` = ?, `time` = ?");
                       $zazp='Sizga Pul o`tkazishdi <b>'.filter2($user['login']).'</b>';
                       if ($smp->execute(array($summ, $_SESSION['send_login'])) && $smph->execute(array(uid($_SESSION['send_login']), $summ, $zazp, $time))){
                           echo '<div class="menu"><center><font color="gren"><b>Siz muvaffaqiyatli o`tkazdingiz '.filter2($_SESSION['send_summ']).' rubl ushbu loginga '.filter2($_SESSION['send_login']).'!</b></font></center></div>';
                           unset($_SESSION['send_summ'], $_SESSION['send_login'], $_SESSION['send_key']);
                           header('Refresh: 2; url=/service/sendmoney');
                       }else {
                        echo '<div class="menu"><center><font color="red">Xato ro`y berdi! [1]</font></center></div>';
                    }
                    }else {
                        echo '<div class="menu"><center><font color="red">Xato ro`y berdi! [2]</font></center></div>';
                    }
                    
                }else {
                    echo '<div class="menu"><center><font color="red"><h1>pul o`tkazmasi xatosi!</h1></font></center></div>';
                           unset($_SESSION['send_summ'], $_SESSION['send_login'], $_SESSION['send_key']);
                           header('Refresh: 2; url=/service/sendmoney');
                }
                }

            }
            echo '<div class="menu">Siz o`tkazdingiz <b>'.filter2($_SESSION['send_summ']).'</b> rubl, ushbu loginga <b>'.filter2($_SESSION['send_login']).'</b></div>';
            echo '<div class="menu"><center><font color="gren">Ushbu <font color="red">'.filter2($user['email']).'</font> e-mailga tasdiqlash kodi yuborildi!</font></center></div>';
            echo '<div class="menu">
            <form action="" method="POST">
            Tasdiqlash kodi:<br/><input type="text" name="send_key"><br/>
            <input class="btn btn-default" type="submit" name="send_verify" value="Tasdiqlash"><input class="btn btn-default" type="submit" name="cancel" value="Bekor qilish">
            </form></div>';

        }

    } else {

        if (isset($_POST['submit'])) {

            $error = '';

            if (empty($_POST['col'])) {
            $error.= 'Miqdorni kiriting!<br/>';
            }
            elseif (!is_numeric($_POST['col'])) {
            $error.= 'Noto‘g‘ri miqdor kiritildi!<br/>';
            }
            $stnum = $connect->prepare("select count(`id`) from `users` where `login` = ?");
            $stnum->execute(array($_POST['login']));
            $num = $stnum->fetchColumn();
            if (empty($_POST['login'])) {
            $error.= 'Qabul qiluvchining loginini kiriting!<br/>';
            }
            elseif ($num == 0) {
            $error.= 'Bunday login bilan foydalanuvchi tizimda topilmaydi.!<br/>';
            }
            elseif ($user['activ'] == 4) {
            $error.= 'Sizning hisobingiz bloklandi! Sizga ruxsat berilmagan!<br/>';
            }
            elseif (mb_strtolower($_POST['login']) == mb_strtolower($user['login'])) {
            $error.= 'Hisobingizga o`tkazib bo`lmaydi!<br/>';
            }
            elseif ($user['money'] < $_POST['col']) {
            $error.= 'Hisobdan pul yetmayapti!<br/>';
            }
            elseif (!preg_match("#^[0-9]{1,15}$#i", $_POST['col'])){
                    $error.= 'OOPS! Faqat Integer!<br/>';
            }
            if ($error) {
                echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
            } else {

                $_SESSION['send_summ'] = $_POST['col'];
                $_SESSION['send_login'] = $_POST['login'];

                $_SESSION['send_key'] = random_int(11111, 99999);

                mailto(
                    $user['email'],
                    'TheDC pul o`tkazmasini tasdiqlash uchun kod',
                    'Tasdiqlash kodi: '.$_SESSION['send_key'],
                    $set['mail']
                );

                header('Location: /service/sendmoney');

            }

        }
        echo '<div class="menu">Ushbu xizmat yordamida aziz do`stlar, siz o`zingizning hisobingizdan pul o`tkazishingiz yoki sotishingiz mumkin.<br/>
        Xizmat narxi <b>'.$amx['amx']['procent'].'%</b> от суммы.</div>';
        echo '<div class="menu"><form action="?" method="post">
        Miqdor:<br/><input type="text" name="col" maxlength="10"/><br/>
        Foydalanuvchi:<br/><input type="text" name="login" maxlength="15"/><br/>
        <input class="btn btn-default" type="submit" name="submit" value="O`tkazmoq"/></form></div>';

    }

}else{
    echo '<div class="menu"><center><font color="red">Sizda pul o`tkazish imkoniyati yo`q!</font></center></div>';
    echo '<div class="menu"><a href="/"> Oldinga</a></div> ';
}
} else {
    header('Location: /');
}

require($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>