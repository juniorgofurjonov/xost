<?php
$title = 'Онлайн';
require_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if ($adm_id == 5) {

    echo '<div class="title">Онлайн ('.$count_online_user.')</div>';

    if ($count_online_user == 0) {
        echo '<div class="menu"><center><font color="red">Онлайн никого нет!</font></center></div>';
    } else {
$k_post = $count_online_user;
$k_page = k_page($k_post, 10); 
$page = page($k_page);
$start = 10 * $page - 10;
        $data = $connect->prepare("select * from `authlog` where `status` = '1' and `lasttime` > :time group by `uid` order by `lasttime` desc limit :start, 10");
        $data->bindValue(':time', time() - 300, PDO::PARAM_INT);
        $data->bindValue(':start', $start, PDO::PARAM_INT);
        $data->execute();
        $sql = $data->fetchAll();

        foreach ($sql as $row) {
            echo '<div class="menu"><img src="/inc/style/img/user.png" alt="'.filter(ulogin($row['uid'])).'"><a href="/adm/users/id/'.$row['uid'].'" >'.filter(ulogin($row['uid'])).'</a> '.online($row['uid']).' ('.date('H:i:s', $row['lasttime']).')';
            echo '<div class="st_1"></div><div class="st_2">IP: '.filter2($row['ip']).'</div></div>';
        }

       if ($k_page > 1) str('?', $k_page, $page);

    }
    echo '<div class="menu">&bull;<a href="/adm/guests/online"> Онлайн гости ('.$count_online_guest.')</a></div>';
    echo '<div class="menu">&bull;<a href="/adm"> Назад</a></div>';
} else {
    header('Location: /');
}

require($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>