<?php
#ini_set('display_errors', 1);
#error_reporting(E_ALL);
$title = 'Тикеты';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
switch($act) {
default:
$q1 = $connect->prepare("SELECT * FROM `tickets` WHERE `id` = ? AND `id_user` = ? LIMIT 1");
$q1->execute(array(val($_GET['id']),$user->id));
$q2 = $connect->prepare("SELECT * FROM `tickets` WHERE `id` = ? AND `id_user` = ? AND `read_user` = ? LIMIT 1");
$q2->execute(array(val($_GET['id']),$user->id,0));
if (!isset($user)){header('Location: /');
exit;
}
if(isset($_GET['id']))
{
if($q1->rowCount()==0)
{
header('Location:/user/tickets');
}
elseif($q2->rowCount()>0)
{
$connect->query("UPDATE `tickets` SET `read_user` = '1' WHERE `id` = '".val($_GET['id'])."'");
header('Location:/user/tickets/id/'.val($_GET['id']).'');
}

$ticket = $connect->prepare("SELECT * FROM `tickets` WHERE `id` = ? LIMIT 1");
$ticket->execute(array(val($_GET['id'])));
$ticket = $ticket->fetch(PDO::FETCH_LAZY);

$otv = val($_GET['otv']);

if (isset($_POST['submit']) && $ticket->close== 0) {
$error = '';
$msg = $_POST['msg'];

if (strlen($_POST['msg']) < 3) {
$error .= '<div class="menu"><center><font color="red">Слишком короткое сообщение.</font></center></div>';
} elseif (empty($_POST['msg'])) {
$error .= '<div class="menu"><center><font color="red">Сообщение пусто.</font></center></div>';
} elseif(strlen($_POST['msg']) > 5000) {
$error .= '<div class="menu"><center><font color="red">Слишком длинное сообщение.</font></center></div>';
} elseif (isset($_SESSION['guest_add'])) {
if ($_SESSION['tiket_add'] > time() - '5') {
$_SESSION['tiket_add'] = time() + 10;
$error.= '<div class="menu"><center><font color="red">Антиспам! Лимит 5 секунд! если еще спам + 10 Сек</font></center></div>';
}
}
$filename = $_FILES['file']['name'];
$filesize = $_FILES['file']['size'];
$ext = strtolower(strrchr($_FILES['file']['name'], '.'));
$form = array('.png', '.jpg', '.jpeg', '.gif');
if (!empty($filename)) {
if ($filesize > (1024 * 3 * 1024)) {
$error .= '<div class="menu"><center><font color="red"> Максимальный размер файла 3 Mb!</font></center></div>';
} elseif ($filesize == 0) {
$error .= '<div class="menu"> Маленький размер файла!</div>';
} elseif (preg_match('/(\.php|\.pl|\.htaccess|\.js)/i', $_FILES['file']['name']) || !in_array($ext, $form)) {
$error .= '<div class="menu"><center><font color="red"> Запрещеный формат файла!</font></center></div>';
}
}
if (!empty($_FILES['file']['name'])) {
$files = 'image_users_'.time().$ext;
} else {
$files = '';
}
if (empty($error)) {

if (!empty($_FILES['file']['name'])) {
copy($_FILES['file']['tmp_name'], $_SERVER['DOCUMENT_ROOT'].'/image/tikets/'.$files);
}
$time=time();
$sql1 = $connect->prepare("INSERT INTO `tickets_msg` SET `id_ticket` = ?, `id_user` = ?, `msg` = ?, `time` = ?, `file` = ?");
$sql1->execute(array($ticket->id,$user->id,$msg,$time,$files));
if (isset($user['tg_id'])) {
$tgmsg='
 Здравствуйте, Admin
У вас новый ответ в тикет!

ID тикета: '.$ticket->id.'
Сообщиние клиент: '.$msg;
    tgmsg('805723653', filteroff($tgmsg), '');
}
$sql2 = $connect->prepare("UPDATE `tickets` SET `read_adm` = ?, `time_update` = ? WHERE `id` = ?");
$sql2->execute(array(0,$time,$ticket->id));
$_SESSION['tiket_add'] = time();
header('Location:/user/tickets/id/'.$ticket->id);
}
}


if (isset($_POST['close'])) {
$sql4 = $connect->prepare("UPDATE `tickets` SET `close` = ? WHERE `id` = ?");
$sql4->execute(array(1,$ticket->id));
header('Location:/user/tickets/id/'.$ticket->id.'');
}

echo '<div class="title">Название тикета: '.$ticket->name.'</div><div class="menu"><b>ID тикета</b>: '.$ticket->id.'';
echo '<br /><b>Категория</b>: ';
if($ticket->id_kat==1)echo 'Финансовый отдел [RU]';
elseif($ticket->id_kat==2)echo 'Финансовый отдел [UZ]';
elseif($ticket->id_kat==3)echo 'Технический отдел [RU]';
elseif($ticket->id_kat==4)echo 'Технический отдел [UZ]';
else echo 'Не указана</font>';

if (isset($error)) echo $error;


$ank_avt = $connect->prepare("SELECT * FROM `users` WHERE `id` = ? LIMIT 1");
$ank_avt->execute(array($ticket->id_user));
$ank_avt = $ank_avt->fetch(PDO::FETCH_LAZY);

echo '<br/>
						<b>Логин</b>: '.ulogin($ank_avt->id).' <br>
						<b>Время создан тикет</b>: '.vremja($ticket->time).'<br/>
						<b>Сообщиние</b>: '.nl2br(smiles(bb(bblinks($ticket->msg)))).'<br/>
';
echo '<b>Состояние тикет</b>: '.($ticket->close=='0'?'<font color="gren">Открыто</font>':'<font color="red">Закрыто</font>').' '.($ticket->close=='0' ? '<form method="post"><input class="btn btn-default" type="submit" name="close" value="Закрыть тикет"/></form>' : '').' ';
echo '</div>';
if ($ticket->close==0) {
include($_SERVER["DOCUMENT_ROOT"]."/inc/smiles_bb.php");
echo '<div class="menu">';
echo '<form method="post" action="/user/tickets/id/'.$ticket->id.'" enctype="multipart/form-data">';
echo '<b>Сообщение</b>:<br/> <textarea rows="5" cols="40" name="msg" required>';
if ($otv != '' && $otv != 0) echo '[b]'.ulogin($otv).'[/b], ';
echo (isset($_POST['msg']) ? filter($_POST['msg']) :NULL).'</textarea><br/><b>Прикрепить скриншот: </b>
<input type="file" name="file"/><br/><input class="btn btn-default" type="submit" name="submit" value="Отправить"/>  <a href="">[Обновить]</a></form>';
echo '</div>';
}

$k_post = $connect->prepare("SELECT COUNT(id) FROM `tickets_msg` WHERE `id_ticket` = ?");
$k_post->execute(array($ticket->id));
$k_post = $k_post->fetchColumn();
$k_page = k_page($k_post, 10);
$page = page($k_page);
$start = 10*$page-10;
$q = $connect->prepare("SELECT * FROM `tickets_msg` WHERE `id_ticket` = ? ORDER BY `time` DESC LIMIT $start, 10");
$q->execute(array($ticket->id));
while ($msg = $q->fetch(PDO::FETCH_LAZY))
{
if($msg->id_user!=$user->id)
	{
		$ank_m = $connect->prepare("SELECT * FROM `users` WHERE `id` = ?");
		$ank_m->execute(array($msg->id_user));
		$ank_m = $ank_m->fetch(PDO::FETCH_LAZY);
	}
else 
	{
		$ank_m = $user;
	}
if ($ank_m['admin'] >= 1) {$c1='adm';}else{$c1='user';}
echo '
						<div class="menu"><img src="/inc/style/img/'.$c1.'.png" alt="'.filter($ank_m->login).'"><a> '.filter($ank_m->login).' </a>'.online(uid($ank_m->login)).' ['.vremja($msg->time).'] '.(($ank_m->id != $user['id']) && $user['ban'] == 0 ? '[<a href="?id='.$ticket->id.'&otv='.$ank_m->id.'">Отв</a>]' : '').' 
						<div class="st_1"></div><div class="st_2">'.nl2br(smiles(bb(bblinks($msg->msg)))).'
					';

if ($msg->file) {
	?>
<br />	<b>Изображения :</b><br />
	<a href = "/image/tikets/<?php echo $msg->file;?>">
		<img width="140" height="100" src = "/image/tikets/<?php echo $msg->file;?>">
	</a>
	<?php
}
echo '</div></div>';

}
echo '<div class="menu">&bull; <a href="/user/tickets/'.($ticket->close=='0' ? '' : 'close/').'">Назад</a></div>';
if ($k_page  > 1) str('/user/tickets/id/'.$ticket->id,$k_page,$page);
}
else
{
 echo '<div class="title">'.$title.'</div>';
$k_post = $connect->prepare("SELECT COUNT(id) FROM `tickets` WHERE `close` = '0' AND `id_user` = ?");
$k_post->execute(array($user->id));
$k_post = $k_post->fetchColumn(0);
if($k_post == 0)
{
echo '<div class="menu">';
echo '<center><font color="red">Тикетов нет.</font></center>';
echo '</div>';
}
$k_page = k_page($k_post, 10);
$page = page($k_page);
$start = 10*$page-10;

// echo '<a href="/user/tickets.php?add">'.$div->link.'Новый тикет'.$div->off.'</a>';

$q = $connect->prepare("SELECT * FROM `tickets` WHERE `close` = '0' AND `id_user` = ? ORDER BY `time_update` DESC LIMIT $start, 10");
$q->execute(array($user->id));
$closet = $connect->prepare("SELECT COUNT(*) FROM `tickets` WHERE `close` = ? AND `id_user` = ?");
$closet->execute(array(1, $user->id));
$closet = $closet->fetchColumn();
while ($ticket = $q->fetch(PDO::FETCH_LAZY))
{
echo '<div class="menu">';
echo '<a href="/user/tickets/id/'.$ticket->id.'">';
echo '
<b>#'.$ticket->id.')</b> '.$ticket->name.' </a> ('.vremja($ticket->time).')
	'.($ticket->read_user==0?'[<font color="red">New</font>]':'').'<br/>';
echo '</div>';}
echo '<div class="menu">&bull; <a href="/user/tickets/close/">Закрытые тикеты ['.$closet.']</a></div>';
if ($k_page  > 1) navigation($k_page, $page);

if(isset($_POST['submit']))
{

if(mb_strlen($_POST['name']) < 3)
{
$error = '<div class="menu"><center><font color="red">Короткое название.</font></center></div>';
}
elseif (empty($_POST['code'])) {
$error = '<div class="menu"><center><font color="red">Введите код с картинки!</font></center></div>';
}
elseif ($_SESSION['code'] != $_POST['code']) {
$error = '<div class="menu"><center><font color="red">Код с картинки введен неверно!</font></center></div>';
}
elseif(mb_strlen($_POST['msg']) < 5)
{
$error = '<div class="menu"><center><font color="red">Короткое сообщение.</font></center></div>';
}
else
{
$name = $_POST['name'];
$msg = $_POST['msg'];
$id_kat = val($_POST['id_kat']);
$sql5 = $connect->prepare("INSERT INTO `tickets` SET `id_user` = ?, `name` = ?, `id_kat` = ?, `msg` = ?, `read_user` = ?,  `time` = ?, `time_update` = ?");
$sql5->execute(array($user->id,$name,$id_kat,$msg,1,$time,$time));
$idaa = $connect->lastInsertId();
if (isset($user['tg_id'])) {
$tgmsg='
 Здравствуйте, Admin
У вас новый тикет!

ID тикета: '.$idaa.'
Сообщиние клиент: '.$msg;
    tgmsg('805723653', filteroff($tgmsg), '');
}
$new_tick = $connect->query("SELECT  * FROM `tickets` WHERE `id` = '".$idaa."'");
$newt = $new_tick->fetch(PDO::FETCH_LAZY);

header('Location:/user/tickets/id/'.$newt['id'].'');
}
}

echo '<div class="title">Новый тикет</div>';
if(isset($error))echo $error;
echo '<div class="menu">';
echo '<form method="post">';
echo '<b>Название</b>:<br/> <input type="text" name="name" value="'.(isset($_POST['name'])?''.filter($_POST['name']).'':'').'" required/><br/>';
echo '<b>Категория</b>:<br/>
<select size="1" name="id_kat">
<option value="1">Финансовый отдел [RU]</option>
<option value="2">Финансовый отдел [UZ]</option>
<option value="3">Технический отдел [RU]</option>
<option value="4">Технический отдел [UZ]</option>
</select><br/>';
echo '<b>Сообщение</b>:<br/> <textarea rows="10" cols="45" name="msg" required>'.(isset($_POST['msg'])?''.filter($_POST['msg']).'':'').'</textarea><br/>';
echo '<b>Код с картинки</b>: <img src="/inc/code.php" alt="check"><br /><input type="text" name="code" /><br/>';
echo '<input class="btn btn-default" type="submit" name="submit" value="Создать"/>';
echo '</div>';

}
break;
case 'close':
echo '<div class="title">Закрытые тикеты </div>';
$k_post = $connect->prepare("SELECT COUNT(id) FROM `tickets` WHERE `close` = '1' AND `id_user` = ?");
$k_post->execute(array($user->id));
$k_post = $k_post->fetchColumn(0);
if($k_post == 0)
{
echo '<div class="menu">';
echo '<center><font color="red">Закрытые тикетов нет.</font></center>';
echo '</div>';
}
$k_page = k_page($k_post, 10);
$page = page($k_page);
$start = 10*$page-10;

$q = $connect->prepare("SELECT * FROM `tickets` WHERE `close` = '1' AND `id_user` = ? ORDER BY `time_update` DESC LIMIT $start, 10");
$q->execute(array($user->id));
while ($ticket = $q->fetch(PDO::FETCH_LAZY))
{
echo '<div class="menu">';
echo '<a href="/user/tickets/id/'.$ticket->id.'">';
echo '
<b>#'.$ticket->id.')</b> '.$ticket->name.' </a> ('.vremja($ticket->time).')
	'.($ticket->read_user==0?'[<font color="red">New</font>]':'').'<br/>';
echo '</div>';}
echo '<div class="menu">&bull; <a href="/user/tickets/">Назад</a></div>';
if ($k_page  > 1) navigation($k_page, $page);
break;
}
} else {
header('Location: /auth');}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>