<?php
$title = 'Пополнение Баланс';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
include_once($_SERVER["DOCUMENT_ROOT"]."/modnn/WapkassaClass.php");
if (isset($active) == true) { 
echo '<div class="title">Пополнение баланс</div>';
// проверка настроек
if (empty($wmr3) && empty($whash) && empty($id_shop) && empty($hash) && empty($wpkid) && empty($wpkh)) {
echo '<div class="menu">======<font color="red">QiWI rub yordamida pul otkazish</font>=====<br/>
Pul otkazish uchun raqam: <font color="red">+998993334419</font><br/>
Summa: <font color="green">istalgan</font><br/>
Masalan: <font color="green">@</font><font color="red">'.filter($user['login']).'</font><br/>
Komentariya: loginingizni <font color="red">@</font> blian yozing!<br/>
===========<font color="red">CLICK</font>======<font color="red">OSON</font>============<br/>
Telegramdan<a href="https://t.me/Bek_Coder"> @Bek_Coder</a> bilan bog`laning!</div>';
} else {
// success
if (isset($_GET['success'])) {
echo '<div class="menu">Вы успешно Пополнил!</div>';
exit(include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php"));
}
elseif (isset($_GET['fail'])) {
// fail
echo '<div class="menu">Произошла ошибка!</div>';
exit(include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php"));
}
// мультивыбор
if (isset($_POST['wm']) xor isset($_POST['wk']) xor isset($_POST['wpk'])) {
// проверка данных
$err = '';
$name = ($_POST['name']);  
if(empty($name))   
{   
$err.= 'Не Верно Сумма!<br/>'; 
}
elseif (!preg_match('/[0-9]+$/i', $name)){
$err.= 'Сумма должен состоять только из цифр!<br/>';
}
if ($err) {
echo '<div class="err">'.$err.'</div>';
} else {
$pay = $connect->prepare("INSERT INTO `rek` SET `num` = ?"); // подготовленный запрос
if (isset($_POST['wm'])) {
// проверка настроек
if (empty($wmr3) && empty($whash)) {
echo '<div class="menu">Данный способ оплаты отключен!</div>';
} else {
$chet = $user->id;
$coma=base64_encode("Пополнение баланс: $user->login");
$sum = $name; 
if ($pay->execute(array($chet))) {
echo '<div class="menu"><form id="'.$whash.'" name="pay" method="POST" action="https://merchant.webmoney.ru/lmi/payment.asp"><input type="hidden" name="LMI_PAYMENT_AMOUNT" value="'.$sum.'"><input type="hidden" name="LMI_PAYMENT_DESC_BASE64" value="'.$coma.'"><input type="hidden" name="LMI_PAYMENT_NO" value="'.$chet.'"><input type="hidden" name="tralala" value="'.$sum.'"><input type="hidden" name="LMI_PAYEE_PURSE" value="'.$wmr3.'"><input type="hidden" name="LMI_SIM_MODE" value="0"><input class="btn btn-default" type="submit" value="Перейти к оплате ('.$sum.' руб.)"></div>';
} else {
echo '<div class="menu">Произошла ошибка!</div>';
}
}
}
elseif (isset($_POST['wpk'])) {
// проверка настроек
if (empty($wpkid) && empty($wpkh)) {
echo '<div class="menu">Данный способ оплаты отключен!</div>';
} else {
$keyh = md5(time());
if ($pay->execute(array($keyh))){
try {
    // Инициализация класса с id сайта и секретным ключом
    $wapkassa = new WapkassaClass($wpkid, $wpkh);

    // основные параметры - сумма и комментарий платежа
    $komm = 'Пополнение баланс: '.$user->login.'';
    $wapkassa->setParams($name, $komm);
    
    
    // допольнительные параметры в виде массива, необязательно
    $wapkassa->setParamsAdd(array(
        'id' => $user->id,
        'key' => $keyh,
    ));
    // получаем данные для генерации формы
    $formValue = $wapkassa->getValue();

    // генерируем ссылку
    //echo '<a class="btn btn-default" href="https://wapkassa.ru/merchant/payment2?' . http_build_query($formValue) . '">Оплатить</a>';
    header('Location: https://wapkassa.ru/merchant/payment2?' . http_build_query($formValue));

} catch (Exception $e) {
    // вывод ошибки
    echo 'Error To OO';
    //echo 'Ошибка: ' . $e->getMessage() . PHP_EOL;
}
}else{
    
}
}
}
elseif (isset($_POST['wk'])) {
// проверка настроек
if (empty($id_shop) && empty($hash)) {
echo '<div class="menu">Данный способ оплаты отключен!</div>';
} else {
$sum = $name;
$summa=$sum;
$comme = 'TheDC.Uz('.$user->login.')';
$data=file_get_contents('http://worldkassa.ru/user/oplata.php?id_shop='.$id_shop.'&summa='.$summa.'&hash='.$hash.'&desc='.urlencode($comme));
if ($pay->execute(array($data))) {
if(is_numeric($data)){ header("Location: http://worldkassa.ru/user/oplata.php?uniq=".$data); }
} else {
echo '<div class="menu">Произошла ошибка!</div>';
}
}
}
}
}
echo '<div class="menu"><b>Ваш баланс</b>: '.$user[money].' Руб</div><div class="menu"> <form action="" method="post" name="form">Сумма:<br/><input name="name" type="text" maxlength="4" /><br/>'.(!empty($wmr3) && !empty($whash) ? '<input name="wm" class="btn btn-default" type="submit" value="WebMoney Merchant" />' : '') . (!empty($id_shop) && !empty($hash) ? '<input name="wk" class="btn btn-default" type="submit" value="WorldKassa" />' : '') . (!empty($wpkid) && !empty($wpkh) ? '<input name="wpk" class="btn btn-default" type="submit" value="WapKassa" />' : '').'</div></form>';
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
 } else {header('Location: /auth');} ?>