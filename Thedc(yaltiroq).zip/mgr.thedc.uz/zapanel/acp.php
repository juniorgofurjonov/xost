<?php
$title='Файл менеджер | Кабинет';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
echo '<div class="title">Файл менеджер | Кабинет</div>';
echo '<div class="err">На разработке';

echo '</div>';
} else {
header('Location: /');
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>