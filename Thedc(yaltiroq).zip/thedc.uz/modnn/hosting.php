<?php 
$k_post = $connect->query("SELECT * FROM `tarifs_hosting` WHERE `activ`='1' AND `id_server` = '1'");
$k_post = $k_post->fetchColumn();
$k_page = k_page($k_post, 10);
$page = page($k_page);
$start = 10*$page-10;

if ($k_post==0) {
    echo '<div class="menu"><center><font color="red">Tariflar yo`q )</font></center></div>';
}

$q = $connect->query("SELECT * FROM `tarifs_hosting` WHERE `activ`='1' AND `id_server` = '1' ORDER BY `sort` ASC LIMIT $start, 10")->fetchAll();

foreach ($q as $hosting){ 

echo '<div class="title">  <b>'.filter($hosting[name]).'</b></div><div class="menu">'; 


echo '<b>Diskdagi joy:</b> '.filter($hosting[hdd]).' MB<br/> 
<b>Trafik:</b> '.filter($hosting[trafic]).' Gb<br/> 
<b>Domenlar/poddomenlar:</b> '.filter($hosting[domain]).' ta.<br/> 
<b>FTP-bog`lanish:</b> '.filter($hosting[ftp]).' ta.<br/> 
<b>POP3-qutusi:</b> '.filter($hosting[mail]).' ta.<br/> 
<b>Ma`lumotlar Bazasi:</b> '.filter($hosting[mysql]).' ta.<br/>
__________________<br/>
<b>kuniga:</b> '.filter($hosting[price_day]).' руб.<br/> 
<b>oyiga:</b> '.filter($hosting[price_month]).' руб.<br/> 
<b>yiliga:</b> '.filter($hosting[price_year]).' руб.<br/>';
if ($user) {   
    if ($user[id_tarif] == $hosting[id]){
        $url = '<div class="okt">Siz ushbu tarifdan foydalanmoqdasiz!</div></div>';
    }else {
       $url = '<a href="/user/smenat/'.$hosting[id].'"><center><button class="glow-on-hover" type="submit">'.filter($hosting[name]).' ga o`tish</button></center></a></div>';
    }
}else{
    $url = '<a href="/reg"><center> <button class="glow-on-hover" type="submit">Buyurtma qilish</button></center></a></div>';
}
echo ' '.$url.'';
} 
if ($k_page > 1) navigation($k_page, $page); 
?>