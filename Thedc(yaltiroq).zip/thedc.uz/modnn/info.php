<?php
$title = 'Malumotlar';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
switch ($act){
default:
echo '<div class="title">Способы оплаты</div><div class="menu">В качестве способа оплаты мы используем WebMoney Merchant/WorldKassa/WapKassa.</div><div class="title">Цены</div><div class="menu">Стоимость перехода: '.$su.' руб.<br />Цвет ссылки: '.$color.' руб.<br/>Статус GOLD: '.$gold.' руб.<br /></div><div class="title">Контакты</div><div class="menu">E-mail: '.$set['mail'].'</div><div class="title">Статус GOLD</div><div class="menu">Статус GOLD включает в себя показ рекламы на всех страницах сайта.</div><div class="forlink"><a href="/info/rules" class="links">Правила сайта</a></div>';
break;
case 'rules':
echo '<div class="title">Qoidalar</div>';
echo '<div class="menu">
<b>1. Xostingda quyidagilar taqiqlanadi:</b><br>
1.1. MDH qonunlariga zid bo`lgan har qanday materiallarni joylashtirish. <br>
1.2. Keraksiz skriptlarni ishga tushirish <br>
1.3. Vayron qiluvchi xatti-harakatlarga olib keladigan resurslarni ko`p sarflaydigan skriptlarni ishga tushirish (Winders / spamerlar / toshqin - skriptlar va boshqalar) <br>
1.4. Mualliflik huquqining buzilishi to`g`risidagi materiallarni joylashtirish (bunga Crack, keygen, nulled/warez dasturlari kiradi) <br>
1.5. DDoS / DoS hujumlarini qiling <br><br><b> 2. Xaridor bajarishi shart: </b> <br>
2.1. Ushbu qoidalarga mutlaqo rioya qiling
2.2. Buyurtmalarni o`z vaqtida to`lang, aks holda buyurtma bekor qilinadi. <br>
2.3. O`zingiz haqingizda ishonchli ma`lumotlarni kiriting. <br>
2.4. Hisob egasini sotish va / yoki almashtirish to`g`risida Ma`muriyatga xabar bering. <br><br><b> 3. Mijoz huquqiga ega: </b> <br>
3.1. To`liq xizmatlardan foydalaning. <br>
3.2. Murojaat qilingan kundan boshlab 24 soat ichida texnik yordam oling. <br>
3.3. Istalgan vaqtda xosting xizmatlaridan voz keching (bu holda ishlatilgan davr uchun pul qaytarilmaydi [!]). <br><b> 4. Ma`muriyat zimmasiga oladi: </b> <br>
4.1. Foydalanuvchilarga reglamentdagi o`zgarishlar, texnik va tashkiliy masalalar to`g`risida xabardor qilish. <br>
4.2. Server uskunasidagi "buyurtma" ni kuzatib boring. <br>
4.3. Mijoz tomonidan taqdim etilgan barcha ma`lumotlarni ularni ruxsatsiz shaxslarga bermasdan saqlash orqali maxfiylikni saqlang (kerak bo`lganda huquqni muhofaza qiluvchi organlar bundan mustasno).
4.4. To`lanmagan buyurtmalarni 7 kundan ortiq bo`lmagan muddatda saqlang (bepul tariflar bundan mustasno). <br>
4.5. Texnik xizmat ko`rsatish jadvali bo`yicha chipta buyurtmalariga javob berish. <br><br><b> 5. Ma`muriyat shart emas: </b> <br>
5.1. Agar foydalanuvchi biron sababga ko`ra buni qila olmasa, skriptlarni o`rnating. <br>
5.2. Mijozning ehtiyojlari uchun serverni sozlash. <br>
5.3. Mijozni xostingga o`rgating. <br>
5.4. Mijoz beparvolik tufayli fayllarni yo`qotib qo`ygan taqdirda zaxira ma`lumotlarini oching. <br>
5.5. Agar qo`ng`iroq xosting doirasidan tashqarida bo`lsa, umr yo`ldosh, tahdid va hokazolar bo`lsa, texnik yordamni taqdim eting <br><br><b> 6. Ma`muriyat quyidagi huquqlarga ega: </b> <br>
6.1. Mijozlarga xizmat ko`rsatishni tushuntirishsiz rad eting. <br>
6.2. Backupa-ni taqdim etmasdan ushbu qoidalarni buzgan foydalanuvchining hisobini blokirovka qiling. <br>
6.3. Agar mijoz Rossiya Federatsiyasi va MDH mamlakatlarining qonunlarini buzgan bo`lsa, huquqni muhofaza qilish idoralariga murojaat qiling. <br><br><b> 7. Ma`muriyat javobgar emas: </b> <br>
7.1. Elektr uzilishlarini qabul qilish uchun. <br>
7.2. Uskunalar uchun; Ushbu uskunada o`rnatilgan dasturiy ta`minot. <br>
7.3. Xakerlik hujumlaridan zarar uchun. <br><br><b> 8 MoneyBack (O`chirish) </b> <br>
8.1. Hostingdan foydalanish paytida istalgan vaqtda WebMoney hisob raqamlariga pul mablag`larini olishni buyurish mumkin (Pochta bilan tekshirgandan so`ng) <br>
8.2 Agar mijoz ushbu qoidalarni buzmagan bo`lsa, pulni olib qo`yish mumkin. <br>
8.3 Pulni olish ish kunlarida (dushanba-juma, dam olish kunlaridan tashqari) 2-10 kun ichida amalga oshiriladi! <br>
8.4 O`rnatish to`lovlari qaytarilmaydi. <br>
8.5 MoneyBack-ni ajratilgan server / VDS / IP-manzil (lar) ga, shuningdek domen (lar) ga buyurtma berish paytida amalga oshirib bo`lmaydi, chunki pul xizmat provayderiga o`tkaziladi.
8.6 Pulni olish 50% miqdorida komissiya bilan amalga oshiriladi. <br><br></div> <div class="err">Diqqat! Ushbu qoidalarni bilmaslik javobgarlikdan ozod qilmaydi! <br>Saytda ro`yxatdan o`tishingiz bilan siz avtomatik ravishda ushbu qoidalarga rozilik bildirasiz.
</div>';
break;
case 'support':
echo '<div class="title"> Qo`llab quvvatlash markazi</div>';
echo '<div class="menu"> Qo`llab-quvvatlash</div><div class="menu"> Qo`llab-quvvatlash barcha savollaringizga javob berishga tayyor (xosting bilan bog`liq).<br>
Ayni paytda mijozlar bilan bog`lanishning bir necha usullari mavjud.<br>
Asosiy kanal bu bizning billing tizimimizga o`rnatilgan chiptalar. <br>
Shuningdek, siz quyidagi aloqa ma`lumotlari orqali biz bilan bog`lanishingiz mumkin: <br>
======<font color="red">Texnik ma`murlar</font>=====<br>
Yaratuvchi: <b>Omonboyev Abdumutal [#Bek]</b><br>
Tizimga kirish: <b>admin</b><br>
E-mail: <b>info@thedc.uz</b><br/>
Telegram: <b>@thedcuz</b><br>
===============================================<br>
Texnik xizmat ko`rsatish jadvali.<br>
Dushanba - Juma (soat 12.00 dan 22.00 gacha UTC +5), <br>
Shanba (soat 18.00 dan 22.00 UTC +5) <br>
Yakshanba - (soat 20.00 dan 22.00 gacha UTC +5) <br>
Sizning chiptangizga kafolatlangan javob berish vaqti - 24 soat<br>
Shuningdek, sizning chiptalaringiz / so`rovlaringiz xodimlarning ish yuklamasiga qarab boshqa vaqtlarda ham ko`rib chiqilishi mumkin. </div> ';
break;
case 'server':
echo '<div class="title">Server</div>';
echo '<div class="menu"># <a>Server №1 [MCK]</a><div class="st_1"></div><div class="st_2"><b>Serverning manzili:</b> Москва<br>
<b>Markaziy protsessor:</b> Intel(R) Xeon(R) CPU E3-1245 V2 @ 3.40GHz<br>
<b>Qattiq disk:</b> SATA<br>
<b>Xotira:</b> 500Gb DDR3<br>
<b>Operatsion tizim:</b> CentOS 7<br>
<b>Aloqa porti:</b> 1Gbps/sec (Unlimited)<br>
<b>IP Manzil:</b> 91.134.253.116 <br>
<b>NS1:</b> ns1.thedc.uz<br>
<b>NS2:</b> ns2.thedc.uz<br>
</div>';
break;
case 'sm':
echo '<div class="title">Справка по смайлам</div><div class="menu">';
for ($i = 1; $i <= count(glob($_SERVER["DOCUMENT_ROOT"]."/img/smiles/*.gif")); $i++) {
echo '<img src="/img/smiles/'.$i.'.gif" alt=""/>:'.$i.':</a>';
}
echo '</div>';
break; 
case 'pay':
echo '<div class="title">Hisobni to`ldirish</div>';
echo '<div class="menu">
Pul otkazish uchun raqam: <font color="red">+998993334419</font><br>
Summa: <font color="green">istalgan</font><br>
Masalan: <font color="green">@</font><font color="red">Abdulhamid</font><br>
Komentariya: loginingizni <font color="red">@</font> blian yozing!<br>
===========<font color="red">CLICK</font>======<font color="red">OSON</font>============<br>
Telegramdan<a href="https://t.me/Bek_Coder"> @Bek_Coder</a> bilan bog`laning!
</div>';

break;
case 'bb':
echo '<div class="title">BB-Ko`dlari</div>';
echo '<div class="menu"><b>Жирный шрифт</b> - [b]Текст[/b]<br/>
<i>Наклоненный шрифт</i> - [i]Текст[/i]<br/>
<u>Подчеркнутый шрифт</u> - [u]Текст[/u]<br/>
Перенос текста - [br]<br/>
Цитата - [cit]Текст[/cit]<br/>
<del>Зачеркнутый шрифт</del> - [del]Текcт[/del]<br/>
<small>Маленький шрифт</small> - [small]Текст[/small]<br/>
<span style="color:red">Цветной шрифт</span> - [color=Цвет]Текст[/color]</div>';
break;
} 
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>