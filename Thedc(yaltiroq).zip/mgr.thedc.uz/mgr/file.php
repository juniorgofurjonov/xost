<?php
//-----Подключаем функции-----//
include 'system/func.php';
include 'system/ftp_connect.php';
switch(@$act){
default:
$d=dir_url('/'.boff(prov($_GET['d'])));
$title='Меню файла "'.basename($d).'"';
include 'system/head.php';
title($title);
if(empty($d)){ 
header('Location: /mgr/explode.php');
}else{
ftp_pasv($serv,true);
$res = ftp_size($serv,$d);
if ($res == '-1') {
header('Location: /mgr/explode.php');
}else{
$path=pathinfo(ftprename($d));
$rf=mb_strtolower($path['extension'],'UTF-8');

if ($rf != 'jpg' && $rf != 'jpeg' && $rf != 'jpe' && $rf != 'png' && $rf != 'gif' && $rf != 'bmp' && $rf != 'ico'){    
echo '<div class="menu"><a class="section" href="/mgr/down.php?d='.bon($d).'"><b>&bull;</b>📥 yuklab olish</a></div>';
}


if ($rf == 'zip'){
echo '<div class="menu"><a class="section" href="/mgr/unzip.php?d='.bon($d).'"><b>&bull;</b>🗄 Arxivdan chiqarish</a></div>
<div class="menu"><a class="section" href="/mgr/zip.php?arh='.bon($d).'"><b>&bull;</b>🔏 Arxivni korish</a></div>';
}
if ($rf == 'sql'){
echo '<div class="menu"><a class="section" href="/mgr/sql.php?d='.bon($d).'"><b>&bull;</b> Загрузка дампа SQL</a></div>';
}
if ($rf != 'jpg' && $rf != 'jpeg' && $rf != 'jpe' && $rf != 'png' && $rf != 'gif' && $rf != 'bmp' && $rf != 'dll' && $rf != 'wav' && $rf != 'mid' && $rf != 'midi' && $rf != 'mp3' && $rf != 'mmf' && $rf != 'psd' && $rf != 'doc' && $rf != 'pdf' && $rf != 'zip' && $rf != 'rar' && $rf != 'jar' && $rf != '3gp' && $rf != 'avi' && $rf != 'mp4' && $rf != 'tgz' && $rf != 'gz' && $rf != 'bz' && $rf != 'gz2' && $rf != 'bz2' && $rf != 'tbz' && $rf != 'tbz2' && $rf != 'tgz2' && $rf != 'tar' && $rf != '7z' && $rf != 'ico') {
echo'<div class="menu"><a class="section" href="/mgr/notepad.php?d='.bon($d).'"><b>&bull;</b>📝 Faylni tahrirlash</a></div>';
echo'<div class="menu"><a class="section" href="/mgr/edit.php?d='.bon($d).'"><b>&bull;</b>🖋 Blacknotda tahrirlash</a></div>';
echo'<div class="menu"><a href="/mgr/quickedit.php?d='.bon($d).'"><b>&bull;</b>🖋 Tezkor tahrirlash <font color="red">[NEW]</font> </a></div>';
$locn = dir_url('/'.$d.'');
$phon = str_replace("/www/","",$locn);
echo'<div class="menu"><a href="https://'.$phon.'"><b>&bull;</b>🌐 browserda ochish <font color="red">[NEW]</font> </a></div>';

echo'<div class="menu"><a class="section" href="/mgr/file.php?act=inzip&amp;d='.bon($d).'"><b>&bull;</b>🔓 Faylni arxivlash</a></div>';
}


echo '<div class="menu"><a class="section" href="/mgr/file.php?act=iconv&amp;d='.bon($d).'"><b>&bull;</b>🔐 Faylni kodlash</a></div>
<div class="menu"><a class="section" href="/mgr/file.php?act=view&amp;d='.bon($d).'"><b>&bull;</b>🔍 Kodni korish</a></div>
<div class="menu"><a class="section" href="/mgr/file.php?act=copy&amp;d='.bon($d).'"><b>&bull;</b>🔗 Faylni nusxalash</a></div>
<div class="menu"><a class="section" href="/mgr/file.php?act=rename&amp;d='.bon($d).'"><b>&bull;</b>✏️ nomni ozgartirish</a></div>';
echo '<div class="menu"><a class="section" href="/mgr/file.php?act=perenos&amp;d='.bon($d).'"><b>&bull;</b>📎 kuchirish</a></div>
<div class="menu"><a class="section" href="/mgr/file.php?act=del&amp;d='.bon($d).'"><b>&bull;</b> ❌ Faylni Ochirish</a></div>
<div class="menu"><a class="section" href="/mgr/file.php?act=clear&amp;d='.bon($d).'"><b>&bull;</b>🗑 Faylni tozalash</a></div>
<div class="menu"><a class="section" href="/mgr/file.php?act=chmod&amp;d='.bon($d).'"><b>&bull;</b>✅ ruxsatnoma</a></div>
<div class="menu"><a class="section" href="/mgr/file.php?act=info&amp;d='.bon($d).'"><b>&bull;</b>📄 Haqida </a></div>';
echo '<div class="menu"><a class="section" href="/mgr/explode.php?d='.bon(verh2($d)).'">&laquo; ◀️ ortga</a></div>';
$locn = dir_url('/'.$d.'');
$phon = str_replace("/www/","",$locn);
if ($rf == 'php' or $rf == 'PHP' or $rf == 'Php' or $rf == 'pHp' or $rf == 'phP' or $rf == 'PHp' or $rf == 'pHP') {




echo '<div class="title"><font align="center">WenHook Sozlash</font></div>';
    
   

?>

<html>

<head>


  <script src="https://unpkg.com/vue/dist/vue.js"></script>
</head>

<body>
    
  <div class="menu">
    
    <div id="app" class="section">
          <font align="center">
      <form :action="set_webhook" method="post" enctype="multipart/form-data">
     <p class="control">
      <label class="label">Tokenni kiriting</label>
        </p>
        <p class="control">
          <input class="input" type="text" v-model="token" />
        </p>
        
        
        <div class="control is-grouped">
          <p class="control">
            <button class="button is-primary" name="submit">Webhookni sozlash</button>
          </p>
       
         </font>
        </div>
    </div>
  </div>
  <script>
    new Vue({
      el: '#app',
      data: {
        token: 'xxxxxxxx:xxxxxxxxxxxxxxxxxx',
        host: '<?php echo $phon;?>',
      },
      computed: {
        get_webhook_info: function () {
          return 'https://api.telegram.org/bot' + this.token + '/getwebhookinfo'
        },
        set_webhook: function () {
          return 'https://api.telegram.org/bot' + this.token + '/setwebhook?url=' + this.host
        },
      }
    }

    )
  </script>
</body>

</html>










<?
}

}
}
ftp_close($serv);
break;
case 'loadfile':
$d=boff(prov($_GET['d']));
if (empty($d)){
header('Location: /mgr/explode.php');
}else{
$res=ftp_size($serv, $d);
if ($res == '-1'){
header('Location: /mgr/explode.php');
}else{
if (ftp_get($serv, 'tmp/'.$savedir.'/'.basename($d), $d, FTP_BINARY)){
////header('Content-Type: application/octet-stream');
header('Content-Length: '.$res);
header('Content-Disposition: attachment; filename='.basename($d));
echo file_get_contents('tmp/'.$savedir.'/'.basename($d));
unlink('tmp/'.$savedir.'/'.basename($d));
exit();
}else{
header('Location: /mgr/file.php?d='.bon($d));
}
}
}
ftp_close($serv);
break;
case 'iconv':
$d=dir_url('/'.boff(prov($_GET['d'])));
$title='Кодировка файла "'.basename($d).'"';
include 'system/head.php';
title($title);
if(empty($d)){ 
header('Location: /mgr/explode.php');
}else{
ftp_pasv($serv,true);
$res = ftp_size($serv,$d);
if ($res == '-1'){
header('Location: /mgr/explode.php');
}else{
if (isset($_POST['ok'])){
$v=prov($_POST['v']);
$iz=prov($_POST['iz']);
$type=intval($_POST['type']);
if (empty($v) || empty($iz)){
$err='<div class="err">Не выбрана кодировка</div>';
}
elseif (empty($type) || $type != '1' && $type != '2'){
$err='<div class="err">Не выбран тип перекодировки</div>';
}
elseif ($iz == $v){
$err='<div class="err">Не возможно перекодировать из <b>'.$iz.'</b> в <b>'.$v.'</b></div>';
}
if (!empty($err)){
err($err);
}else{
if (ftp_get($serv, 'tmp/'.$savedir.'/recode.txt', $d, FTP_BINARY)) {
$file=file_get_contents('tmp/'.$savedir.'/recode.txt');
$file=iconv($iz,$v,$file);
file_put_contents('tmp/'.$savedir.'/recode.txt', $file);
if (ftp_put($serv, $d.''.($type == '2'?'.ftp':''), 'tmp/'.$savedir.'/recode.txt', FTP_BINARY)) {
echo '<div class="ok">Кодировка файла успешно изменена</div>';
unlink('tmp/'.$savedir.'/recode.txt');
} else {
err('<div class="err">Не удалось перекодировать файл</div>');
}
} else {
err('<div class="error">Не удалось зугрузить файл на сервер</div>');
}
}
}
echo '<div class="menu"><form method="post">Кодировка оригинала:<br/>
<select name="iz"><option value="utf-8" selected="selected">utf-8</option><option value="windows-1251">windows-1251</option><option value="koi8-r">koi8-r</option><option value="cp866">cp866</option><option value="cp1251">cp1251</option><option value="iso-8859-1">iso-8859-1</option></select>
<br/>Новая кодировка:<br/><select name="v"><option value="utf-8" selected="selected">utf-8</option><option value="windows-1251">windows-1251</option><option value="koi8-r">koi8-r</option><option value="cp866">cp866</option><option value="cp1251">cp1251</option><option value="iso-8859-1">iso-8859-1</option></select>
<br/>Тип перекодировки:<br/><input type="radio" name="type" value="1" checked="checked"> Перезаписать файл<br/><input type="radio" name="type" value="2"> Сохранить в новый файл<b>.ftp</b><br/><input class="btn btn-default" type="submit" name="ok" value="Перекодировать"></form></div>';
}
}
ftp_close($serv);
break;
case 'view':
$d=dir_url('/'.boff(prov($_GET['d'])));
$title='Код файла "'.basename($d).'"';
include 'system/head.php';
title($title);
if(empty($d)){ 
header('Location: /mgr/explode.php');
}else{
ftp_pasv($serv,true);
$res = ftp_size($serv,$d);
if ($res == '-1'){
header('Location: /mgr/explode.php');
}else{
if (ftp_get($serv, 'tmp/'.$savedir.'/'.basename($d), $d, FTP_BINARY)) {
$file=file_get_contents('tmp/'.$savedir.'/'.basename($d));
if (empty($file)){
err('Файл пуст');
}else{
$code=highlight_string($file, true);
$code=preg_replace('#<code>(.*)</code>#sU','\1',$code);
echo '<div class="menu">'.$code.'</div>';
}
unlink('tmp/'.$savedir.'/'.basename($d));
 } else {
err('<div class="err">Не удалось зугрузить файл на сервер</div>');
}
}
}
ftp_close($serv);
break;
case 'chmod':
$d=dir_url('/'.boff(prov($_GET['d'])));
$title='Права доступа файла "'.basename($d).'"';
include 'system/head.php';
title($title);
if(empty($d)){ 
header('Location: /mgr/explode.php');
}else{
ftp_pasv($serv,true);
$res = ftp_size($serv,$d);
if ($res == '-1'){
header('Location: /mgr/explode.php');
}else{
if (isset($_POST['ok'])){
$chmod=intval($_POST['chmod']);
if (empty($chmod)){
$err='<div class="err">Не введены права доступа</div>';
}
elseif (!preg_match('#^[0-9]{3}+$#sU',$chmod) || !is_numeric($chmod) || strlen($chmod) != 3){
$err='<div class="err">Права доступа введены не верно</div>';
}
if (!empty($err)){
err($err);
}else{
if (ftp_site($serv, 'CHMOD 0'.$chmod.' '.$d)){
echo '<div class="ok">Права доступа успешно изменены</div>';
} else {
err('<div class="err">Не удалось изменить права доступа</div>');
}
}
}
echo '<div class="menu"><form method="post">Права доступа (chmod):<br/><input type="text" name="chmod" value="'.chminf($serv, $d).'"><br/><input class="btn btn-default" type="submit" name="ok" value="Изменить"></form></div>';
}
}
ftp_close($serv);
break;
case 'del':
$d=dir_url('/'.boff(prov($_GET['d'])));
$title='Удаление файла "'.basename($d).'"';
include 'system/head.php';
title($title);
if(empty($d)){ 
header('Location: /mgr/explode.php');
}else{
ftp_pasv($serv,true);
$res = ftp_size($serv,$d);
if ($res == '-1'){
header('Location: /mgr/explode.php');
}else{
if (isset($_GET['ok'])){
$content = api_query('https://'.$server->ip.'/ispmgr?func=file.delete&elid=' .urlencode(substr($d, 1)). '&out=xml&authinfo=' . $user['isp_login'] . ':' . $user['isp_pass']);
        $parse_xml = simplexml_load_string($content);
        if (isset($parse_xml->ok)) {
header('Location: /mgr/explode.php?d='.bon(verh2($d)));
} else {
err('<div class="err">Не удалось удалить файл</div>');
}
}else{
echo '<div class="menu">Вы действительно хотите удалить данный файл?<br/><center><a href="/mgr/file.php?act=del&amp;ok&amp;d='.bon($d).'">Да</a> | <a href="/mgr/file.php?d='.bon($d).'">Нет</a></center></div>';
}
}
}
ftp_close($serv);
break;
case 'clear':
$d=dir_url('/'.boff(prov($_GET['d'])));
$title='Очистка файла "'.basename($d).'"';
include 'system/head.php';
title($title);
if(empty($d)){ 
header('Location: /mgr/explode.php');
}else{
ftp_pasv($serv,true);
$res = ftp_size($serv,$d);
if ($res == '-1'){
header('Location: /mgr/explode.php');
}else{
if (isset($_GET['ok'])){
$fi=ftprename($d);
file_put_contents('tmp/'.$savedir.'/'.$fi,'',0664);
if (ftp_put($serv, $d, 'tmp/'.$savedir.'/'.$fi, FTP_BINARY)){
echo '<div class="success">Файл успешно очищен</div>';
unlink('tmp/'.$savedir.'/'.$fi);
} else {
err('<div class="err">Не удалось очистить файл</div>');
}
}else{
echo '<div class="menu">Вы действительно хотите очистить данный файл?<br/><center><a href="/mgr/file.php?act=clear&amp;ok&amp;d='.bon($d).'">Да</a> | <a href="/mgr/file.php?d='.bon($d).'">Нет</a></center></div>';
}
}
}
ftp_close($serv);
break;
case 'rename':
$d=dir_url('/'.boff(prov($_GET['d'])));
$title='Переименование файла "'.basename($d).'"';
include 'system/head.php';
title($title);
if(empty($d)){ 
header('Location: /mgr/explode.php');
}else{
ftp_pasv($serv,true);
$res = ftp_size($serv,$d);
if ($res == '-1'){
header('Location: /mgr/explode.php');
}else{
if (isset($_POST['ok'])){
$name=prov($_POST['name']);
if (empty($name)){
$err='<div class="err">Не введено название файла</div>';
}
elseif (!preg_match('#^[A-z0-9_\-\.]+$#sU',$name)){
$err='<div class="err">Обнаружены запрещённые символы. Разрешено: A-z0-9_-.</div>';
}
if (!empty($err)){
err($err);
}else{
$newdir=dir_url('/'.ftprename2($d).'/'.$name);
if (ftp_rename($serv,$d,$newdir)) {
header('Location: /mgr/explode.php?d='.bon(verh2($d)));
} else {
err('<div class="err">Не удалось переименовать файл</div>');
}
}
}
echo '<div class="menu"><form method="post">Название файла (A-z0-9_-.):<br/><input type="text" name="name" value="'.ftprename($d).'"><br/><input class="btn btn-default" type="submit" name="ok" value="Переименовать"></form></div>';
}
}
ftp_close($serv);
break;
case 'perenos':
$d=dir_url('/'.boff(prov($_GET['d'])));
$title='Перемещение файла "'.basename($d).'"';
include 'system/head.php';
title($title);
if (empty($d)){
header('Location: /mgr/explode.php');
}else{
ftp_pasv($serv,true);
$res = ftp_size($serv,$d);
if ($res == '-1'){
header('Location: /mgr/explode.php');
}else{
if (isset($_POST['ok'])){
$put=prov($_POST['put']);
if (!empty($put)){
$put=dir_url('/'.$put.'/');
$verh=dir_url('/'.verh2($d).'/');
}
if (empty($put)){
$err='<div class="err">Не введён путь перемещения файла</div>';
}
elseif (!preg_match('#^[A-z0-9_\-\/\.]+$#sU',$put)){
$err='<div class="err">Обнаружены запрещённые символы. Разрешено: A-z0-9_-/.</div>';
}
//elseif ($put == $verh){$err='<div class="error">Данный файл и так находится в этой директории</div>';}
if (!empty($err)){
err($err);
}else{
$newdir=dir_url('/'.$put.'/'.basename($d));
if (ftp_rename($serv,$d,$newdir)) {
header('Location: /mgr/explode.php?d='.bon($put));
} else {
err('<div class="err">Не удалось переместить файл</div>');
}
}
}
$value=dir_url('/'.verh2(verh2($d)).'/');
echo '<div class="menu"><form method="post">Путь перемещения (A-z0-9_-/.):<br/><input type="text" name="put" value="'.$value.'"><br/><input class="btn btn-default" type="submit" name="ok" value="Переместить"></form></div>';
}
}
ftp_close($serv);
break;
case 'copy':
$d=dir_url('/'.boff(prov($_GET['d'])));
$title='Копирование файла "'.basename($d).'"';
include 'system/head.php';
title($title);
if(empty($d)){ 
header('Location: /mgr/explode.php');
}else{
ftp_pasv($serv,true);
$res = ftp_size($serv,$d);
if ($res == '-1'){
header('Location: /mgr/explode.php');
}else{
if (isset($_POST['ok'])){
$put=prov($_POST['put']);
if (!empty($put)){
$put=dir_url('/'.$put.'/');
$verh=dir_url('/'.verh2($d).'/');
}
if (empty($put)){
$err='<div class="err">Не введён путь копирования</div>';
}
elseif (!preg_match('#^[A-z0-9_\-\/\.]+$#sU',$put)){
$err='<div class="err">Обнаружены запрещённые символы. Разрешено: A-z0-9_-/.</div>';
}
//elseif ($put == $verh){$err='<div class="error">Данный файл уже есть в этой директории</div>';}
if (!empty($err)){
err($err);
}else{
$newdir=dir_url('/'.$put.'/'.basename($d));
if (ftp_get($serv, 'tmp/'.$savedir.'/'.basename($d), $d, FTP_BINARY)) {
if (ftp_put($serv, $newdir, 'tmp/'.$savedir.'/'.basename($d), FTP_BINARY)) {
unlink('tmp/'.$savedir.'/'.basename($d));
header('Location: /mgr/explode.php?d='.bon($put));
} else {
err('<div class="err">Не удалось скопировать файл</div>');
}
} else {
err('<div class="err">Не удалось зугрузить файл на сервер</div>');
}
}
}
$value=dir_url('/'.verh2(verh2($d)).'/');
echo '<div class="menu"><form method="post">Путь копирования (A-z0-9_-/.):<br/><input type="text" name="put" value="'.$value.'"><br/><input class="btn btn-default" type="submit" name="ok" value="Копировать"></form></div>';
}
}
ftp_close($serv);
break;
case 'inzip':
$d=dir_url('/'.boff(prov($_GET['d'])));
$title='Архивирование файла "'.basename($d).'"';
include 'system/head.php';
title($title);
if(empty($d)){ 
header('Location: /mgr/explode.php');
}else{
ftp_pasv($serv,true);
$res = ftp_size($serv,$d);
if ($res == '-1'){
header('Location: /mgr/explode.php');
}else{
if (isset($_POST['ok'])){
$name=prov($_POST['name']);
if (empty($name)){
$err='<div class="err">Не введено название архива</div>';
}
elseif (!preg_match('#^[A-z0-9_\-\.]+$#sU',$name)){
$err='<div class="err">Обнаружены запрещенные символы. Разрешено: A-z0-9_-.</div>';
}
if (!empty($err)){
err($err);
}else{
mkdir('tmp/'.$savedir.'/archive',0777);
if (ftp_get($serv, 'tmp/'.$savedir.'/archive/'.basename($d), $d, FTP_BINARY)){
include 'system/pclzip.php';
$zip=new PclZip('tmp/'.$savedir.'/'.$name.'.zip');
if ($zip->create('tmp/'.$savedir.'/archive/'.basename($d), PCLZIP_OPT_REMOVE_ALL_PATH) != false){
ftp_put($serv, dir_url('/'.verh2($d).'/'.$name.'.zip'), 'tmp/'.$savedir.'/'.$name.'.zip',FTP_BINARY);
unlink('tmp/'.$savedir.'/'.$name.'.zip');
deldir('tmp/'.$savedir.'/archive');
unlink('tmp/'.$savedir.'/'.basename($d));
header('Location: /mgr/explode.php?d='.bon(verh2($d)));
    }else{
err('<div class="err">Ошибка создания архива</div>');
	}
	}else{
err('<div class="err">Ошибка загрузки файла на сервер</div>');
	}
	}
}
$value=pathinfo($d);
if ($value['basename'] != '.htaccess'){
$value=str_replace('.'.$value['extension'],'',$value['basename']);
}else{
$value='htaccess';
}
echo '<div class="menu"><form method="post">Название архива (A-z0-9_-.):<br/><input type="text" name="name" value="'.$value.'">.zip<br/><input class="btn btn-default" type="submit" name="ok" value="Архивировать"></form></div>';
}
}
ftp_close($serv);
break;
case 'info':
$d=dir_url('/'.boff(prov($_GET['d'])));
$title='Информация о файле "'.basename($d).'"';
include 'system/head.php';
title($title);
if (empty($d)){
header('Location: /mgr/explode.php');
}else{
$res=ftp_size($serv, $d);
if ($res == '-1'){
header('Location: /mgr/explode.php');
}else{
echo '<div class="menu">Название: '.basename($d).'<br/>Размер: '.sizer($res).'<br/>Права доступа: '.chminf($serv, $d).''.(dirinf($serv, $d, 'user') !=false?'<br/>Владелец: '.dirinf($serv, $d, 'user'):'').''.(dirinf($serv, $d, 'group') != false?'<br/>Группа: '.dirinf($serv, $d, 'group'):'').''.(dirinf($serv, $d, 'date') != false?'<br/>Дата создания: '.dirinf($serv, $d, 'date'):'').'</div>';
}
}
ftp_close($serv);
break;
}
if ($act){
echo '<div class="menu"><a class="section" href="/mgr/file.php?d='.prov($_GET['d']).'">&laquo; Назад</a></div>';
}
include 'system/foot.php';
?>